﻿using Common;
using Domen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace KorisnickiInterfejs
{
    public class Komunikacija
    {
        
        private static Komunikacija instance;
        private Socket socket;
        private KomunikacijaHelper helper;

        #region singleton
        private Komunikacija()
        {

        }
        public static Komunikacija Instance 
        { 
            get { 
                if (instance == null) 
                { 
                    instance = new Komunikacija();
                }
                return instance;
            }
        }
        #endregion

        internal void OdjavljenKlijent()
        {
            Request r = new Request(Operacija.KRAJ);
            helper.Send<Request>(r);
            
        }

        public void Connect()
        {
            if (socket == null || !socket.Connected)
            {
                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                socket.Connect("127.0.0.1", 9999);
                helper = new KomunikacijaHelper(socket);
            }
        }

        internal Korisnik Login(Korisnik p)
        {
            Request r = new Request(Operacija.LOGIN, p);
            helper.Send<Request>(r);
            return (Korisnik)helper.Receive<Response>().Result;
            
        }
    }
}
