﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorisnickiInterfejs
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Korisnik p = new Korisnik
            {
                Username = txtUsername.Text,
                Password = txtPassword.Text
            };

            if (p.Username == null || p.Username == "" || p.Password==null || p.Password=="")
            {
                MessageBox.Show("Morate uneti kredencijale!");
                return;
            }

            try
            {
                Komunikacija.Instance.Connect();
                p = Komunikacija.Instance.Login(p);
            }
            catch (SocketException ex)
            {
                MessageBox.Show("Server nije pokrenut!");
                return;

            }
            catch (IOException ex)
            {
                MessageBox.Show("Server nije pokrenut!");
                return;
            }
                 
            

            if(p==null)
            {
                MessageBox.Show("Neuspesna prijava!Probajte ponovo!");
                return;
            }

            this.Visible = false;
            FrmMain forma = new FrmMain(p);
            forma.ShowDialog();
            //this.Visible = true;
            //this.Dispose();

        }
    }
}
