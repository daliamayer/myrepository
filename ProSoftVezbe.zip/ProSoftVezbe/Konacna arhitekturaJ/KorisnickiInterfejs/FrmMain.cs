﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorisnickiInterfejs
{
    public partial class FrmMain : Form
    {
        private Korisnik prijavljeni;
        BindingSource bs = new BindingSource();
        public FrmMain()
        {
            InitializeComponent();
        }

        public FrmMain(Korisnik p)
        {
            InitializeComponent();
            // BINDING SOURCE
            bs.DataSource = Komunikacija.Instance.VratiIntervencijeUpravnika(p);
            dgvIntervencije.DataSource = bs;
            prijavljeni = p;

            // DGV COMBO BOX KOLONA - ZA KLASU
            try
            {
                DataGridViewComboBoxColumn cbStambenaZajednicaColumn = new DataGridViewComboBoxColumn
                {
                    DataSource = Komunikacija.Instance.VratiStambeneZajedniceUpravnika(p),
                    HeaderText = "Stambena zajednica",
                    DataPropertyName = "StambenaZajednica", //odredjuje za koji property Product-a ce vrednost cb biti vezana
                    ValueMember = "Self", // odredjuje koji property Manufacturer-a ce biti vracen!!! u klasi Manufacturer mora da postoji property Self koji vraca this!!!!
                    DisplayMember = "Naziv" //property Manufacturer-a koji treba da prikaze u cb //bez ovoga nece raditi!!!!!!
                };
                dgvIntervencije.Columns.Add(cbStambenaZajednicaColumn);
            }
            catch (Exception ex)
            {

                Console.WriteLine(">>>>>>>>>>" + ex.Message);
            }

            // DGV COMBO BOX KOLONA - ZA ENUM
            DataGridViewComboBoxColumn cbStatusColumn = new DataGridViewComboBoxColumn
            {
                DataSource = Komunikacija.Instance.VratiStatuse(),
                HeaderText = "Status",
                DataPropertyName = "Status", //odredjuje za koji property Product-a ce vrednost cb biti vezana
            };

            // MENJANJE HEADERA 
            //dgvIntervencije.Columns[0].HeaderText = "Datum pocetka";

        }

        // kad sa main forme otvaramo novu formu (npr. za dodavanje nekog slabog objekta)
        // i u nekom slucaju treba zatvoriti tu formu (npr. validacija prilikom dodavanja nije 
        // prosla), pored this.Dispose() mora da se uradi i return iz te metode, jer ce u suprotnom
        // nastaviti dalje sa njenim izvrsavanjem

        #region validacija
        private bool validacija()
        {
            try
            {
                DateTime datumPoc = DateTime.ParseExact(txtDatVremePocetka.Text, "dd/MM/yy HH:mm", null);
                DateTime datumKraj = DateTime.ParseExact(txtDatVremeKraja.Text, "dd/MM/yy HH:mm", null);
                if (datumPoc > datumKraj)
                {
                    MessageBox.Show("Datum pocetka mora biti pre datuma kraja!");
                    return false;
                }
                razlika = (int)((datumKraj - datumPoc).TotalMinutes);  //timespan


            }
            catch (FormatException ex)
            {

                MessageBox.Show("Niste uneli datum u dobrom formatu");
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtBox.Text))
            {
                MessageBox.Show("Niste uneli naziv emisije!");
                return false;
            }

            // regex za string koji sadrzi samo brojeve
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtJMBG.Text, @"^[0-9]*$") ||
               txtJMBG.Text.Length != 1)
            {
                MessageBox.Show("JMBG mora biti u odgovarajucem formatu!");
                return;
            }

            // regex za email
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtEmail.Text, @"[a-z0-9]+@[a-z]+\.[a-z]{2,3}"))
            {
                MessageBox.Show("Email mora biti u odgovarajucem formatu!");
                return;
            }

            // parsiranje enuma
            NacinEmitovanja = (NacinEmitovanja)Enum.Parse(typeof(NacinEmitovanja), cbNacinEmitovanja.SelectedItem.ToString());

            // vadjenje karaktera iz stringa 
            string polt = u.Takmicenje.NazivTakmicenja[len - 2].ToString();      // [] vraca char
            string poltt = u.Takmicenje.NazivTakmicenja.Substring(len - 2, 1);  // substring vraca string

            // PARTSIRANJE DATUMA SA TRYPARSE
            if (!DateTime.TryParseExact(textBox1.Text, "dd/MM/yy",
               null, System.Globalization.DateTimeStyles.None, out DateTime datum))
            {
                MessageBox.Show("Datum nije u dobrom formatu!");
                return;
            }
        }

        #endregion

        #region disableKolone
        private void dgvAngazovanja_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (e.ColumnIndex == 3)
            {
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
            }
        }
        #endregion

        #region dogadjajiSaDGV
        private void dgvProfesori_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            Profesor p = KontrolerZ23.Instance.VratiProfesora(e.RowIndex + 1);
            if (p.Status == Status.PENZIONISAN)
            {
                btnSave.Enabled = false;
            }
            else
            {
                btnSave.Enabled = true;
            }
            txtID.Text = p.Sifra.ToString();
            txtIme.Text = p.Ime;
            txtPrezime.Text = p.Prezime;
            txtStatus.Text = p.Status.ToString();
            txtZvanje.Text = p.Zvanje.ToString();

        }

        #endregion

        #region sortiranjePoDvaParametra
        List<Angazovanje> nova = angazovanja.OrderBy(a => a.Profesor.ToString()).ThenBy(a => a.Predmet.Naziv).ToList();
        #endregion

        #region sortiranjeEnuma
        var niz = Enum.GetValues(typeof(Tip)) as Tip[];
        cbTip.DataSource = niz.OrderBy(enm => enm.ToString()).ToArray();
        #endregion

        #region brisanjeIzDGV
        private void btnObrisiUcesce_Click(object sender, EventArgs e)
        {
            if (dgvUcesca.SelectedRows == null || dgvUcesca.SelectedRows.Count == 0)
            {
                MessageBox.Show("Morate selektovati red da biste ga obrisali!");
                return;
            }

            Ucesce u = (Ucesce)dgvUcesca.SelectedRows[0].DataBoundItem;
            ucesca.Remove(u);

            // azuriranje rb
            int rb = 1;
            foreach (StavkaPrijave stavka in stavkePrijave)
            {
                stavka.RB = rb;
                rb++;
            }
            dgvUcesca.DataSource = null;
            dgvUcesca.DataSource = ucesca;

        }
        #endregion

        #region dodavanjeUDGV
        private void btnDodajUcesce_Click(object sender, EventArgs e)
        {
            Ucesce u = new Ucesce();
            u.Takmicenje = (Takmicenje)cbTakmicenje.SelectedItem;
            u.Takmicar = (Takmicar)cbTakmicar.SelectedItem;
            u.VrstaTrke = (VrstaTrke)cbVrstaTrke.SelectedItem;
            u.Organizator = prijavljeniProducent;
            try
            {
                u.DatumVremePocetka = DateTime.ParseExact(txtDatumVremePocetka.Text, "dd/MM/yy HH:mm", null);
                u.DatumVremeZavrsetka = DateTime.ParseExact(txtDatumVremeZavrsetka.Text, "dd/MM/yy HH:mm", null);
            }
            catch (FormatException ex)
            {

                MessageBox.Show("Niste uneli datum u dobrom fromatu!");
                return;
            }
            if (u.Takmicar == null || u.Takmicenje == null || u.VrstaTrke == null)
            {
                MessageBox.Show("Morate popuniti sva polja!");
                return;
            }
            if (!validacija(u))
            {
                MessageBox.Show("Validacija nije uspesna!");
                return;
            }
            ucesca.Add(u);
            dgvUcesca.DataSource = null;
            dgvUcesca.DataSource = ucesca;
            txtDatumVremePocetka.Text = "";
            txtDatumVremeZavrsetka.Text = "";
        }
        #endregion

        #region otvaranjeNoveFormeKadJeKonekcijaNaGlavnojFormi
        private void sacuvajKadJeKonekcijaNaMain()
        {
            // Mora ovako, ne moze sa this.Close() ili this.Dispose(),
            // verovatno jer je sad konekcija na main formi, a ne na login kao do sad
            // moglo je i preko visible = false i u frmClosed eventu bi bio Environment.Exit

            // I NACIN 
            // formaM = new frmMain();
            // this.Visible = false;
            // formaM.Show();
            // + u frmClosed eventu Environment.Exit

            // II NACIN
            frmMain formaM = new frmMain();
            formaM.Show();
            formaM.FormClosing += (obj, args) => { this.Close(); };
            this.Hide(); // isto kao i this.Visible = false;

            // III NACIN - prazniti polja 

        }
        #endregion

        #region otvaranjeNoveFormeNakonSubmitovanja
        private void sacuvaj()
        {
            FrmMain forma = new FrmMain(prijavljeniProducent);
            this.Dispose();
            forma.ShowDialog();
        }
        #endregion

        #region zamenaPostojecegElementaUListiNovim
        private void izmena()
        {
            int index = zahtevi.FindIndex(x => x.ID == forma.Zahtev.ID);
            zahtevi[index] = forma.Zahtev;
        }
        #endregion

        #region nullEnumUComboBoxu
        private void nullEnum()
        {
            if (cbStatus.SelectedItem == null) { Zahtev.Status = null; } //ovde je bacalo nullreferenceexception
                                                                         //pa smo dodale if, ne znamo sto je bacao,
                                                                         //mozda zbog kastovanja null u enum
        }
        #endregion

        #region VisestrukiKlik
           Application.DoEvents();
        #endregion

        #region DodavanjeNaPocetakIIzbacivanjeSKrajaListe
            zaIzmenu.Insert(0, i);
            zaIzmenu.RemoveAt(3);
            #endregion

        // za greske sa DGV - dataError event
        private void FrmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            Komunikacija.Instance.OdjavljenKlijent();
            Environment.Exit(0);
        }
    }
}
