﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public enum Operacija
    {
        LOGIN,
        KRAJ
    }
    [Serializable]
    public class Request
    {
        public Request(Operacija operation, object requestObject=null)
        {
            Operation = operation;
            RequestObject = requestObject;
        }

        public Operacija Operation { get; set; }
        public object RequestObject { get; set; }
    }
}
