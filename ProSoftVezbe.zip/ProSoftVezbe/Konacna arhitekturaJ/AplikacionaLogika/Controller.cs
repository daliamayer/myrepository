﻿using BrokerBazePodataka;
using Domen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplikacionaLogika
{
    public class Controller
    {
        private static Controller instance;
        Broker broker = new Broker();

        //List<Korisnik> korisnici = new List<Korisnik>()
        //{
        //    new Korisnik
        //    {
        //        Id=1,
        //        Ime="Pera",
        //        Prezime="Peric",
        //        Username="pera",
        //        Password="pera"
        //    },
        //    new Korisnik
        //    {
        //        Id=2,
        //        Ime="Mika",
        //        Prezime="Mikic",
        //        Username="mika",
        //        Password="mika"
        //    },

        //};

        #region singleton
        private Controller()
        {

        }
        public static Controller Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Controller();
                }
                return instance;
            }
        }
        #endregion

        public Korisnik Login(Korisnik p)
        {
            try
            {
                broker.OpenConnection();
                List<Korisnik> org = broker.VratiKorisnike();
                return org.FirstOrDefault(x=> x.Username==p.Username && x.Password==p.Password);
            }
            finally
            {
                broker.CloseConnection();
            }
        
        }

        #region loginIzOperativne

        //public Korisnik Login(Korisnik p)
        //{
        //    return korisnici.FirstOrDefault(x => x.Username == p.Username && x.Password == p.Password);
        //}
        #endregion

        #region sacuvajPodTransakcijom
        //public void SacuvajPodTransakcijom(Emisija e, List<Angazovanje> an)
        //{
        //    try
        //    {
        //        broker.OpenConnection();
        //        broker.BeginTransaction();
        //        broker.SacuvajEmisijeIAngazovanja(e, an);
        //        broker.Commit();

        //    }
        //    catch (Exception ex)
        //    {
        //        broker.Rollback();
        //    }
        //    finally
        //    {
        //        broker.CloseConnection();
        //    }
        //}
        #endregion

        #region izvestajFiltriranjeSaSlanjemUslova

        public List<Izvestaj> VratiIzvestaj(Studio s, DateTime? datumOdC, DateTime? datumDoC)
        {
            string uslov = "";
            string datumOd = null;
            string datumDo = null;

            // PRETRAGA PO DELU NASLOVA ILI TEKSTA
            if (uslov != "")
            {
                string pom = uslov.ToUpper();
                upit = " WHERE UPPER(v.Naslov) LIKE '%" + pom + "%' or UPPER(v.Tekst) LIKE '%" + pom + "%'"; //LIKE U UPITU!! ZA PRETRAGU DELOVA TEKSTA
                                                                                                             // % = nula ili vise karaktera posle
            }

            if (datumOdC != null)
            {
                // MORA OVAJ FORMAT DATUMA KOJI JE I U BAZI !!!!!
                datumOd = datumOdC.Value.Date.ToString("yyyyMMdd HH:mm:ss"); // RADI I BEZ HH:mm: ss kad radimo CAST
            }
            if (datumDoC != null)
            {
                datumDo = datumDoC.Value.Date.ToString("yyyyMMdd HH:mm:ss");
            }
            try
            {
                if (s != null && datumOd != null && datumDo != null)
                {
                    uslov = uslov + $"where e.StudioID={s.ID} and e.DatumVremePocetka>='{datumOd}' " +
                        $"and e.DatumVremeKraja<='{datumDo}'";

                    // CAST da bismo vreme iz baze stavili na 00:00:00
                    uslov = uslov + $"where e.LaboratorijaID={s.LaboratorijaID} and CAST(e.DatumVremeRezultata AS Date)>='{datumOd}' " +
                    $"and CAST(e.DatumVremeRezultata AS Date)<='{datumDo}' and";
                }
                if (s != null && datumOd != null && datumDo == null)
                {
                    uslov = uslov + $"where e.StudioID={s.ID} and e.DatumVremePocetka>='{datumOd}'";
                }
                if (s != null && datumOd == null && datumDo == null)
                {
                    uslov = uslov + $"where e.StudioID={s.ID}";
                }
                if (s == null && datumOd != null && datumDo != null)
                {
                    uslov = uslov + $"where e.DatumVremePocetka>='{datumOd}' " +
                        $"and e.DatumVremeKraja<='{datumDo}'";
                }
                if (s == null && datumOd != null && datumDo == null)
                {
                    uslov = uslov + $"where e.DatumVremePocetka>='{datumOd}'";
                }
                if (s == null && datumOd == null && datumDo != null)
                {
                    uslov = uslov + $"where e.DatumVremeKraja<='{datumDo}'";
                }
                if (s != null && datumOd == null && datumDo != null)
                {
                    uslov = uslov + $"where e.StudioID={s.ID} and e.DatumVremeKraja<='{datumDo}'";
                }
                if (s == null && datumOd == null && datumDo == null)
                {
                    uslov = "";
                }

                broker.OpenConnection();
                return broker.VratiIzvestaj(uslov);
            }
            finally
            {
                broker.CloseConnection();
            }
        }

        #endregion

        #region cuvanjeKaoStoJeUDGV(dodavanje,izmena,brisanje)
        public void SacuvajIntervencije(List<Intervencija> intervencije, Upravnik u)
        {

            try
            {
                broker.OpenConnection();

                // MORA PRE ZAPOCINJANJA TRANSAKCIJE JER U NJEMU NE POSTAVLJAMO TRANSAKCIJU
                List<Intervencija> intervencijeBaza = broker.VratiIntervencijeUpravnika(u);
                broker.BeginTransaction();


                if (intervencijeBaza == null || intervencijeBaza.Count == 0)
                {
                    foreach (Intervencija i in intervencije)
                    {
                        broker.DodajIntervenciju(i, u);
                    }
                    return;
                }

                if (intervencije == null || intervencije.Count == 0)
                {
                    foreach (Intervencija i in intervencijeBaza)
                    {
                        broker.ObrisiIntervenciju(i);
                    }
                    return;
                }



                foreach (Intervencija ib in intervencijeBaza)
                {
                    bool update = false;
                    foreach (Intervencija i in intervencije)
                    {
                        if (ib.Id == i.Id)
                        {
                            broker.IzmeniIntervenciju(i, u);
                            update = true;
                            break;
                        }
                    }
                    if (update == false) broker.ObrisiIntervenciju(ib);
                }



                foreach (Intervencija i in intervencije)
                {
                    if (i.Id == 0) broker.DodajIntervenciju(i, u);
                }

                broker.Commit();

            }
            catch (Exception ex)
            {
                broker.Rollback();
            }
            finally
            {
                broker.CloseConnection();
            }
        }
        #endregion

        #region cuvanjeJakogISlabihObjekata
        public void VraitSacuvajIgru(Igra i)
        {
            try
            {
                broker.OpenConnection();
                broker.BeginTransaction();
                broker.SacuvajIgru(i);
                int rb = 1;
                foreach (Dostupnost d in i.Dostupnosti)
                {
                    broker.SacuvajDostupnost(d, i.IgraID, rb);
                    rb++;
                }
                broker.Commit();

            }
            catch (Exception ex)
            {
                broker.Rollback();
                Console.WriteLine(ex.Message);
            }
            finally
            {
                broker.CloseConnection();
            }
        }
        #endregion


    }
}
