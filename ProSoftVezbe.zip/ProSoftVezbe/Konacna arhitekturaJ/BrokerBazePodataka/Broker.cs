﻿using Domen;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrokerBazePodataka
{
    public class Broker
    {
        private SqlConnection connection;
        private SqlTransaction transaction;

        public Broker()
        {
            connection = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ProSoft-Jul2021;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

        }

        public void OpenConnection()
        {

            connection.Open();
        }

        public void CloseConnection()
        {
            if (connection != null && connection.State != ConnectionState.Closed)
                connection.Close();
        }

        #region cuvanjeJakogISlabihObjekata
        public void SacuvajJakISlabeObjekte(Emisija e, List<Angazovanje> angazovanja)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.Transaction = transaction;

            command.CommandText = "insert into Emisija" +
                  " output inserted.EmisijaId values" +
                  " (@nazivEmisije, @datumPoc, @datumKraj, @nacinEm,@producent," +
                  "@voditelj,@studio)";

            command.Parameters.AddWithValue("@nazivEmisije", e.Naziv);
            command.Parameters.AddWithValue("@datumPoc", e.DatumVremePocetka);
            command.Parameters.AddWithValue("@datumKraj", e.DatumVremeKraja);
            command.Parameters.AddWithValue("@nacinEm", e.NacinEmitovanja.ToString());
            command.Parameters.AddWithValue("@producent", e.Producent.ImePrezime);
            command.Parameters.AddWithValue("@voditelj", e.Voditelj.ID);
            command.Parameters.AddWithValue("@studio", e.Studio.ID);


            int emisijaId = (int)command.ExecuteScalar();

            if (angazovanja == null || angazovanja.Count == 0) return;

            foreach (Angazovanje a in angazovanja)
            {

                // mora svaki put nova komanda inace se buni zbog parametara koji se isto zovu
                command = new SqlCommand("", connection, transaction);
                command.CommandText = "insert into Angazovanje values" +
                " (@vrstaAng, @opisPosla, @brSati, @emId, @radnikId)";
                command.Parameters.AddWithValue("@vrstaAng", a.VrstaAngazovanja.ToString());
                command.Parameters.AddWithValue("@opisPosla", a.OpisPosla);
                command.Parameters.AddWithValue("@brSati", a.BrojSati);
                command.Parameters.AddWithValue("@emId", emisijaId);
                command.Parameters.AddWithValue("@radnikId", a.Radnik.ID);

                command.ExecuteNonQuery();
            }
        }
        #endregion

        #region vratiIzbaze
        public List<Korisnik> VratiKorisnike()
        {
            List<Korisnik> korisnici = new List<Korisnik>();
            SqlCommand command = new SqlCommand("", connection);
            command.CommandText = "SELECT * FROM Korisnik";
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Korisnik r = new Korisnik();
                    r.Id = reader.GetInt32(0);
                    r.Ime = reader.GetString(1);
                    r.Prezime = reader.GetString(2);
                    r.Username = reader.GetString(3);
                    r.Password = reader.GetString(4);

                    // DODATNE STVARI

                    p.Status = (Status)Enum.Parse(typeof(Status), (string)reader["Status"]);  // enum string
                    p.Zvanje = (Zvanje)reader["Zvanje"];  //enum int

                    //kad puca get metoda readera, ako se vraca dbNull iz baze
                    try
                    {
                        r.DatumVremePocetka = reader.GetDateTime(1);
                    }
                    catch (SqlNullValueException ex)
                    {

                        r.DatumVremePocetka = null;
                    }

                    TimeSpan ts = r.DatumVremeZavrsetka - r.DatumVremePocetka;

                    // TimeSpan se ispisuje u formatu dd.HH:mm:ss
                    // nama je trebalo HH:mm

                    // za prikaz dana u satima, i da sklonimo sekunde, da ne bi ispisivalo 4.0:00:00 
                    // nego 96:00
                    r.VremeTakmicara = string.Format("{0:00}:{1:00}", (int)ts.TotalHours, ts.Minutes);

                    korisnici.Add(r);
                }
            }
            return korisnici;
        }
        #endregion

        #region izvestajSaFiltriranjemISlanjemUslova+CASE
        public List<Izvestaj> VratiIzvestajServerSaSlanjemUslova(string uslov)
        {
            List<Izvestaj> izvestaji = new List<Izvestaj>();
            SqlCommand command = new SqlCommand("", connection);
            command.CommandText = "SELECT s.Naziv as studio, count(distinct e.EmisijaID) as ukupnoEmisija, " +
                "sum(a.BrojSati) as ukupnoSati FROM Emisija e join Studio s on (e.StudioID=s.StudioID) " +
                "left join Angazovanje a on (a.EmisijaID=e.EmisijaID) " + uslov + " group by s.StudioID,s.Naziv";

            // CASE
            command.CommandText = "SELECT e.Tip,sum(case when e.Rezultat='Pozitivan' then 1 else 0 end" +
                "), sum(case when e.Rezultat='Negativan' then 1 else 0 end) " +
                "FROM Zahtev e " + uslov + " e.Status='Obradjen' GROUP BY e.Tip";

            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Izvestaj r = new Izvestaj();
                    r.Studio = new Studio
                    {
                        Naziv = reader["studio"].ToString()
                    };
                    r.UkupnoEmisija = (int)reader["ukupnoEmisija"];

                    if (reader["ukupnoSati"] != DBNull.Value)  //DBNULL
                    {
                        r.UkupnoSati = (int)reader["ukupnoSati"];
                    }
                    else
                    {
                        r.UkupnoSati = 0;
                    }


                    izvestaji.Add(r);
                }
            }
            return izvestaji;
        }
        #endregion

        #region izvestajSaListomSlabihObjekataKadZnamoKolikoImaSlabihObjekata
        public List<Izvestaj> VratiIzvestaj()
        {
            List<Izvestaj> studiji = new List<Izvestaj>();
            SqlCommand command = new SqlCommand("", connection);
            command.CommandText = "select p.PrognozaID, p.Dan, m.Ime, m.Prezime, r.Naziv, pr.Temperatura, " +
                "pr.MeteoAlarm, pr.Pojava from Prognoza p join PrognozaRegion pr on (p.PrognozaID=pr.PrognozaID) " +
                "join Meteorolog m on (m.MeteorologID=p.MeteorologID) join Region r on (r.RegionID=pr.RegionID)";

            using (SqlDataReader reader = command.ExecuteReader())
            {
                int i = 1;
                string pom = "";
                while (reader.Read())
                {
                    Izvestaj r = new Izvestaj();
                    if (i < 5)
                    {
                        string reg = reader.GetString(4);
                        // NIJE RADILO SA GETFLOAT IAKO JE U BAZI FLOAT, MORA GETDOUBLE, NE ZNAMO STO
                        double temp = reader.GetDouble(5);
                        string metAl = reader.GetString(6);
                        string poj = reader.GetString(7);

                        pom = pom + "" + reg + ": " + temp + " (" + metAl + ", " +
                            poj + ");";
                        i++;
                    }
                    else
                    {
                        string reg = reader.GetString(4);
                        double temp = reader.GetDouble(5);
                        string metAl = reader.GetString(6);
                        string poj = reader.GetString(7);

                        pom = pom + "" + reg + ": " + temp + " (" + metAl + ", " +
                            poj + ");";
                        r.Dan = reader.GetDateTime(1);
                        string met = reader.GetString(2) + " " + reader.GetString(3);
                        r.Meteorolog = met;
                        r.Prognoza = pom;
                        pom = "";
                        i = 1;
                        studiji.Add(r);
                    }


                }
            }
            return studiji;
        }
        #endregion

        #region izvestajSaListomSlabihObjekataKadNeZnamoKolikoImaSlabihObjekata
        public List<Izvestaj> vratiIzvestaje()
        {

            SqlCommand command = new SqlCommand("", connection);
            command.CommandText = "SELECT RegruterID from Regruter";
            List<int> regruteri = new List<int>();

            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {

                    int id = reader.GetInt32(0);
                    regruteri.Add(id);

                }
            }


            List<Izvestaj> izvestaji = new List<Izvestaj>();

            foreach (int i in regruteri)
            {
                command.CommandText = "SELECT k.ImePrezime,r.ImePrezime from Intervju i join Kandidat k on" +
                    $" (i.KandidatID=k.KandidatID) join Regruter r on (i.RegruterID=r.RegruterID)" +
                    $" where i.RegruterID={i}";
                string s = "";
                int brojac = 0;
                string regruter = "";

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {

                        s = s + reader.GetString(0) + ", ";
                        brojac++;
                        regruter = reader.GetString(1);
                    }
                }

                Izvestaj izv = new Izvestaj();
                izv.Regruter = regruter;
                izv.UkupanBrojKandidata = brojac;
                int pom = s.Length;
                izv.Kandidati = s.Substring(0, pom - 2);
                izvestaji.Add(izv);
            }

            return izvestaji;

        }
        #endregion

        #region updateBezParametara_EnumIntString
        public void IzmeniProfesora(Profesor p)
        {
            SqlCommand command = new SqlCommand("", connection);
            command.Transaction = transaction;
            command.CommandText = $"update Profesori set Ime='{p.Ime}', Prezime='{p.Prezime}', Zvanje={(int)p.Zvanje}, Status='{p.Status.ToString()}' where ID={p.Sifra}";
            command.ExecuteNonQuery();

        }
        #endregion

        #region updateSaParametrima_DBNull
        public void IzmeniIntervenciju(Intervencija i, Upravnik u)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.Transaction = transaction;
            
                command.CommandText = "update Intervencija" +
                    " set DatumVremePocetka=@datumPoc, DatumVremeZavrsetka=@datumZav, " +
                    "Opis=@opis, AngazovanjeIzvodjacaRadova=@angazovanjeIzvRad, Cena=@cena," +
                    "Status=@status, VrstaIntervencijeID=@vrstaIntId, " +
                    "StambenaZajednicaID=@stamZajId, UpravnikID=@uprId " +
                    $"where IntervencijaID={i.Id}";


                if (i.DatumVremePocetka == null)
                {
                    command.Parameters.AddWithValue("@datumPoc", DBNull.Value);
                }
                else
                {
                    command.Parameters.AddWithValue("@datumPoc", i.DatumVremePocetka);
                }
                if (i.DatumVremeZavrsetka == null)
                {
                    command.Parameters.AddWithValue("@datumZav", DBNull.Value);
                }
                else
                {
                    command.Parameters.AddWithValue("@datumZav", i.DatumVremeZavrsetka);
                }
                command.Parameters.AddWithValue("@opis", i.Opis);
                command.Parameters.AddWithValue("@angazovanjeIzvRad", i.AngazovanjeIzvodjacaRadova);
                command.Parameters.AddWithValue("@cena", i.Cena);
                command.Parameters.AddWithValue("@status", i.Status.ToString());
                command.Parameters.AddWithValue("@vrstaIntId", i.VrstaIntervencije.Id);
                command.Parameters.AddWithValue("@stamZajId", i.StambenaZajednica.Id);
                command.Parameters.AddWithValue("@uprId", u.Id);

                int intId = (int)command.ExecuteNonQuery();
                Console.WriteLine("Izmenjena intervencija: " + intId);

         
        }
        #endregion

        #region brisanje
        public void ObrisiIntervenciju(Intervencija i)
        {
            SqlCommand command = new SqlCommand("", connection);
            command.CommandText = $"delete from Intervencija where IntervencijaID={i.Id}";
            command.Transaction = transaction;
            int br = command.ExecuteNonQuery();
            Console.WriteLine("Obrisani redovi: " + br);
        }
        #endregion

        #region maxId
        private int maxID()
        {
            int prognozaId;

            SqlCommand command = new SqlCommand("", connection);
            command.CommandText = "SELECT max(PrognozaID) FROM Prognoza";
            // MORA POD TRANSAKCIJOM JER EXECUTE SKALAR ZAHTEVA TRANSAKCIJU
            command.Transaction = transaction;

            try
            {
                int pom = (int)command.ExecuteScalar();
                prognozaId = pom + 1;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                prognozaId = 1;

            }

            return prognozaId;

        }
        #endregion

        #region maxIDSaRezervisanjem
        List<int> zauzetiID = new List<int>();
        public object VratiIgraID()
        {
            SqlCommand command = new SqlCommand("", connection);
            command.CommandText = "SELECT max(IgraID) FROM Igra";
            int id = 0;
            try
            {
                id = (int)command.ExecuteScalar() + 1;
            }
            catch (Exception)
            {
                id = 1;

            }

            if (zauzetiID.Contains(id))
            {
                id = zauzetiID.Max() + 1;
            }
            zauzetiID.Add(id);

            return id;

        }
        #endregion


        public void BeginTransaction()
        {
            transaction = connection.BeginTransaction();
        }

        public void Commit()
        {
            transaction.Commit();
        }

        public void Rollback()
        {
            transaction.Rollback();
        }




    }
}
