﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Korisnik
    {
        [Browsable(false)] // ako necemo da se prikazuje u dgv
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string ImePrezime { get { return Ime + " " + Prezime; } }

        // self property
        public Korisnik Self { get { return this; } }


        //OVO JE AKO BISMO HTELI SAMO DA PRIKAZUJEMO SAMO DATUM U DATA GRID VIEW, BEZ VREMENA
        /* 
        private DateTime datumvremetestiranja;
        public DateTime DatumVremeTestiranja
        {
        get { return this.datumvremetestiranja.Date; }
        set { datumvremetestiranja = value; }
        } 
        */

        public override string ToString()
        {
            return ImePrezime;
        }

        public override bool Equals(object obj)
        {
            if(obj is Korisnik k)
            {
                return k.Id == this.Id;
            }
            return false;
        }
    }
}
