﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class FrmServer : Form
    {
        private Server s;
        public FrmServer()
        {
            InitializeComponent();
            s = new Server();
            if (s.Start())
            {
                MessageBox.Show("Server je pokrenut!");
                Thread nit = new Thread(s.Listen);
                nit.IsBackground = true;
                nit.Start();

                //System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
                //timer.Interval = 5000;
                //timer.Tick += Timer_Tick;
                //timer.Start(); 

            }
            else
            {
                MessageBox.Show("Server nije pokrenut!");
            }
        }

        // NA KLIK MENJAMO TEKST PO KOM SE FILTRIRA, TJ USLOV, A ONDA TAJ USLOV SALJEMO U VRATIIZVESTAJ
        //string uslov = "";
        //private void btnPretraga_Click(object sender, EventArgs e)
        //{
        //    uslov = txtPretraga.Text;
        //}

        #region TimerTickSaFiltriranjem
        //private void Timer_Tick(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        Studio s;
        //        DateTime? datumOd;
        //        DateTime? datumDo;

        //        if (chBStudio.Checked && cbStudio.SelectedItem != null)
        //        {
        //            s = (Studio)cbStudio.SelectedItem;
        //        }
        //        else
        //        {
        //            s = null;
        //        }

        //        if (chBDatumOd.Checked && !string.IsNullOrWhiteSpace(txtDatumOd.Text) && !string.IsNullOrEmpty(txtDatumOd.Text))
        //        {
        //            datumOd = DateTime.ParseExact(txtDatumOd.Text, "dd/MM/yy", null);
        //        }
        //        else
        //        {
        //            datumOd = null;
        //        }

        //        if (chBDatumDo.Checked && !string.IsNullOrWhiteSpace(txtDatumDo.Text) && !string.IsNullOrEmpty(txtDatumDo.Text))
        //        {
        //            datumDo = DateTime.ParseExact(txtDatumDo.Text, "dd/MM/yy", null);
        //        }
        //        else
        //        {
        //            datumDo = null;
        //        }

        //        dgvIzvestaj.DataSource = null;
        //        dgvIzvestaj.DataSource = Controller.Instance.VratiIzvestaj(s, datumOd, datumDo);
        //    }
        //    catch (FormatException ex)
        //    {
        //        return;
        //    }
        //}
        #endregion



        private void FrmServer_FormClosed(object sender, FormClosedEventArgs e)
        {
            
            Environment.Exit(0);
        }
    }
}
