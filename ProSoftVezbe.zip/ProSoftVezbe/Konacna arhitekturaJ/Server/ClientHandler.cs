﻿using AplikacionaLogika;
using Common;
using Domen;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class ClientHandler
    {
        private Socket socket;
        private KomunikacijaHelper helper;

        public EventHandler OdjavljenKlijent;

        public ClientHandler(Socket socket)
        {
            this.socket = socket;
            helper = new KomunikacijaHelper(socket);
        }

        private bool kraj = false;
        public void HandleRequests()
        {
            try
            {
                while (!kraj)
                {
                    Request request = helper.Receive<Request>();
                    CreateResponse(request);
                    
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(">>>" + ex.Message);
            }
            finally
            {
                CloseSocket();
            }
        }


        public void CreateResponse(Request request)
        {
            Response response = new Response();
            try
            {
                switch (request.Operation)
                {
                    case Operacija.LOGIN:
                        response.Result = Controller.Instance.Login((Korisnik)request.RequestObject);
                        if (response.Result == null)
                        {
                            response.IsSuccessful = false;
                            response.Message = "Korisnik ne postoji!";
                        }
                        helper.Send(response);  // NE ZABORAVI!!!!
                        break;
                    case Operacija.KRAJ:
                        kraj = true;
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                response.IsSuccessful = false;
                response.Message = ex.Message;
            }
            
        }

        // NE ZNAM STA JE, RAZJASNI
        private object lockobject = new object();
        internal void CloseSocket()
        {
            lock (lockobject)
            {
                if (socket != null)
                {
                    kraj = true;
                    socket.Shutdown(SocketShutdown.Both);
                    socket.Close();
                    socket = null;
                    OdjavljenKlijent?.Invoke(this, EventArgs.Empty);
                }
            }
        }

        #region MetodaDodajURecnikStaraINovaZnacenja
        private void DodajURecnik(Poruka message)
        {
            SrpskaRec s = message.RecZaRecnik;
            List<EngleskaRec> novaZnacenja = new List<EngleskaRec>();
            //List<EngleskaRec> staraZnacenja = new List<EngleskaRec>();
            bool postoji = false;

            foreach (SrpskaRec item in Controller.Instance.recnik)
            {
                if (item.Equals(s))
                {
                    foreach (EngleskaRec e in s.EngleskaZnacenja)
                    {
                        if (item.EngleskaZnacenja.Contains(e))
                        {
                            continue;
                        }
                        else
                        {
                            novaZnacenja.Add(e);
                        }

                    }
                    if (novaZnacenja == null || novaZnacenja.Count == 0)
                    {
                        return;
                    }
                    SendToAll(s, item.EngleskaZnacenja, novaZnacenja);
                    item.EngleskaZnacenja.AddRange(novaZnacenja);
                    return;
                }
            }

            Controller.Instance.recnik.Add(s);

            SendToAll(s);

        }
        #endregion

    }
}
