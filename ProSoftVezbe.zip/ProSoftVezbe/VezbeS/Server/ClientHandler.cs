﻿using AplikacionaLogika;
using Common;
using Domen;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class ClientHandler
    {
        private Socket socket;
        private KomunikacijaHelper helper;

        public EventHandler OdjavljenKlijent;

        public ClientHandler(Socket socket)
        {
            this.socket = socket;
            helper = new KomunikacijaHelper(socket);
        }

        private bool kraj = false;
        public void HandleRequests()
        {
            try
            {
                while (!kraj)
                {
                    Request request = helper.Receive<Request>();
                    CreateResponse(request);
                    
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(">>>" + ex.Message);
            }
            finally
            {
                CloseSocket();
            }
        }


        public void CreateResponse(Request request)
        {
            Response response = new Response();
            try
            {
                switch (request.Operation)
                {
                    case Operacija.LOGIN:
                        response.Result = Controller.Instance.Login((Korisnik)request.RequestObject);
                        if (response.Result == null)
                        {
                            response.IsSuccessful = false;
                            response.Message = "Korisnik ne postoji!";
                        }
                        helper.Send(response);
                        break;
                    case Operacija.KRAJ:
                        kraj = true;
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(">>>" + ex.Message);
                response.IsSuccessful = false;
                response.Message = ex.Message;
            }
            
        }

        
        private object lockobject = new object();
        internal void CloseSocket()
        {
            lock (lockobject)
            {
                if (socket != null)
                {
                    kraj = true;
                    socket.Shutdown(SocketShutdown.Both);
                    socket.Close();
                    socket = null;
                    OdjavljenKlijent?.Invoke(this, EventArgs.Empty);
                }
            }
        }
    }
}
