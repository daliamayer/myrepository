﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Korisnik
    {
        [Browsable(false)]
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string ImePrezime { get { return Ime + " " + Prezime; } }
        public override string ToString()
        {
            return ImePrezime;
        }
        public override bool Equals(object obj)
        {
            if(obj is Korisnik k)
            {
                return k.Id == this.Id;
            }
            return false;
        }
    }
}
