﻿using Domen;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrokerBazePodataka
{
    public class Broker
    {
        private SqlConnection connection;
        private SqlTransaction transaction;

        public Broker()
        {
            connection = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ProSoft-Jul2021;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

        }

        public void OpenConnection()
        {

            connection.Open();
        }

        public void CloseConnection()
        {
            if (connection != null && connection.State != ConnectionState.Closed)
                connection.Close();
        }

        public void BeginTransaction()
        {
            transaction = connection.BeginTransaction();
        }

        public void Commit()
        {
            transaction.Commit();
        }

        public void Rollback()
        {
            transaction.Rollback();
        }


        public List<Korisnik> VratiKorisnike()
        {
            List<Korisnik> studiji = new List<Korisnik>();
            SqlCommand command = new SqlCommand("", connection);
            command.CommandText = "SELECT * FROM Organizator";
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Korisnik r = new Korisnik();
                    r.Id = reader.GetInt32(0);
                    r.Ime = reader.GetString(1);
                    r.Prezime = reader.GetString(2);
                    r.Username = reader.GetString(3);
                    r.Password = reader.GetString(4);


                    studiji.Add(r);
                }
            }
            return studiji;
        }

    }
}
