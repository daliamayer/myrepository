﻿using BrokerBazePodataka;
using Domen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplikacionaLogika
{
    public class Controller
    {
        private static Controller instance;
        Broker broker = new Broker();

        //List<Korisnik> korisnici = new List<Korisnik>()
        //{
        //    new Korisnik
        //    {
        //        Id=1,
        //        Ime="Pera",
        //        Prezime="Peric",
        //        Username="pera",
        //        Password="pera"
        //    },
        //    new Korisnik
        //    {
        //        Id=2,
        //        Ime="Mika",
        //        Prezime="Mikic",
        //        Username="mika",
        //        Password="mika"
        //    },

        //};


        #region singleton
        private Controller()
        {

        }
        public static Controller Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Controller();
                }
                return instance;
            }
        }
        #endregion

        public Korisnik Login(Korisnik p)
        {
            try
            {
                broker.OpenConnection();
                List<Korisnik> org = broker.VratiKorisnike();
                return org.FirstOrDefault(x=> x.Username==p.Username && x.Password==p.Password);
            }
            finally
            {
                broker.CloseConnection();
            }
        }

        #region sacuvajPodTransakcijom
        //public void SacuvajPodTransakcijom(Emisija e, List<Angazovanje> an)
        //{
        //    try
        //    {
        //        broker.OpenConnection();
        //        broker.BeginTransaction();
        //        broker.SacuvajEmisijeIAngazovanja(e, an);
        //        broker.Commit();

        //    }
        //    catch (Exception ex)
        //    {
        //        broker.Rollback();
        //    }
        //    finally
        //    {
        //        broker.CloseConnection();
        //    }
        //}
        #endregion




    }
}
