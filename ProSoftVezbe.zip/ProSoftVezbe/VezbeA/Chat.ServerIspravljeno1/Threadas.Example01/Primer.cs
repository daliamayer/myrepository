﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Threads.Example01
{
    public class Primer
    {
        public int Broj { get; set; }
        private object lockObject = new object();

        public void UvecajBroj()
        {
            //object lockObject = new object(); ne moze!!!
            Console.WriteLine("Pocetak: " + Thread.CurrentThread.Name);
            while (Broj < 100)
            {
                lock (lockObject)
                {
                    if (Broj < 100)
                    {
                        Broj++;
                        Console.WriteLine(Thread.CurrentThread.Name + " " + Broj);
                        Thread.Sleep(500);
                    }
                }
            }
            Console.WriteLine("Kraj: " + Thread.CurrentThread.Name);
        }


    }
}
