﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Threads.Example01;

namespace Threads.Example01
{
    class Program
    {
        static void Main(string[] args)
        {
            Primer p = new Primer();

            //Thread.CurrentThread.Name = "Glavna programska nit";
            Thread nit1 = new Thread(p.UvecajBroj);
            nit1.Name = "Nit 1";
            nit1.IsBackground = true;

            Thread nit2 = new Thread(p.UvecajBroj);
            nit2.Name = "Nit 2";
            nit2.IsBackground = true;

            Console.WriteLine(nit1.ThreadState);
            nit1.Start();
            nit2.Start();
            Console.WriteLine(nit1.ThreadState);
            //p.Ispisi();

            //nit1.Join();
            //nit2.Join();
            //Console.WriteLine("Broj " + p.Broj);
            //Console.WriteLine(nit1.ThreadState);

            Console.WriteLine("Kraj programa!");
            Console.ReadKey();
            
        }

      
    }
}
