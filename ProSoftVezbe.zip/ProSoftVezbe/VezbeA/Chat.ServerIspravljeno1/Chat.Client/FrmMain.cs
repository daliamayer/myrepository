﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chat.Client
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {

            InitializeComponent();
            rtbMessages.Visible = false;
            btnSend.Visible = false;
            txtMessage.Visible = false;
            try
            {
                Communication.Instance.Connect();
               

            }
            catch (SocketException ex)
            {
                MessageBox.Show(ex.Message);
                Environment.Exit(0); //throw;
               
            }
           
        }

        private void InitListener()
        {
            Thread nit = new Thread(CitajPoruke);
            nit.IsBackground = true;
            nit.Start();
        }

        private void CitajPoruke()
        {
            try
            {
                while (true)
                {
                    Common.Message m = Communication.Instance.ReadMessage();

                    switch (m.Operation)
                    {
                        case Common.Operation.Login:
                            Invoke(new Action(() => { rtbMessages.AppendText(Environment.NewLine + "Korisnik sa korisnickim imenom "+m.Name +" se uspesno prijavio"); }));
                            break;
                        case Common.Operation.SendToAll:
                            Invoke(new Action(() => { rtbMessages.AppendText(Environment.NewLine + m.Name + ": " + m.Text); }));
                            break;
                        case Common.Operation.End:
                            Invoke(new Action(() => { MessageBox.Show("Server je pao!"); Environment.Exit(0); }));
                            break;
                        case Common.Operation.OdjavljenKlijent:
                            Invoke(new Action(() => { rtbMessages.AppendText(Environment.NewLine + "Klijent " +m.Name+" se odjavio!");  }));
                            break;
                        default:
                            break;
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            
            Common.Message message = new Common.Message { Text = txtMessage.Text, Operation = Common.Operation.SendToAll };
            Communication.Instance.Send(message);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Common.Message message = new Common.Message { Name = txtName.Text, Operation = Common.Operation.Login };
            Communication.Instance.Send(message);
            Common.Message odgovorOdServera = Communication.Instance.ReadMessage();
            if (odgovorOdServera.IsSuccessful)
            {
                MessageBox.Show("Uspesna prijava!");
                txtName.Visible = false;
                btnLogin.Visible = false;
                rtbMessages.Visible = true;
                btnSend.Visible = true;
                txtMessage.Visible = true;
                InitListener();
            }
            else
            {
                MessageBox.Show(odgovorOdServera.ErrorText);
            }

        }

        private void FrmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            Common.Message message = new Common.Message {  Operation = Common.Operation.End };
            Communication.Instance.Send(message);
            Environment.Exit(0);
        }
    }
}
