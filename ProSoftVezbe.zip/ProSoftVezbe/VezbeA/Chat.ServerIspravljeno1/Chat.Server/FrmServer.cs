﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chat.Server
{
    public partial class FrmServer : Form
    {
        private Server server;
        private System.Windows.Forms.Timer timer;
        public FrmServer()
        {
            InitializeComponent();
            server = new Server();

             timer = new System.Windows.Forms.Timer();
            timer.Interval = 1000;

            timer.Tick += Timer_Tick;
            
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            lblTimer.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        private Thread nitVreme;
        private bool kraj = false;
        private void btnStartTime_Click(object sender, EventArgs e)
        {
            timer.Start();
           
            //nitVreme = new Thread(this.PokreniPrikazVremena);
            //kraj = false;
            //nitVreme.Start();
        }

        private void PokreniPrikazVremena()
        {
            try
            {
                while (!kraj)
                {
                    this.Invoke(new Action(() =>
                    {
                        lblTime.Text = DateTime.Now.ToString("HH:mm:ss");
                    }));
                    //this.Invoke(new Action(AzurirajLabelu));
                    Thread.Sleep(1000);
                }
            }
            catch (ThreadInterruptedException)
            {
                MessageBox.Show("Nit je zaustavljena!");
            }
        }
        //lblTime.Text = DateTime.Now.ToString("HH:mm:ss");

        private void AzurirajLabelu()
        {
            lblTime.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        private void btnStopTime_Click(object sender, EventArgs e)
        {
            timer.Stop();
            //nitVreme.Interrupt();
            // kraj = true;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                server.Start();

                Thread nit = new Thread(server.HandleClients);
                nit.IsBackground = true;
                nit.Start();
                MessageBox.Show("Server je pokrenut!");
            }
            catch (SocketException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FrmServer_FormClosed(object sender, FormClosedEventArgs e)
        {
            server.Stop();
            Environment.Exit(0);
        }

        private void btnStop_Click_1(object sender, EventArgs e)
        {
            server.Stop();
        }
    }
}
