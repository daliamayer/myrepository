﻿using Chat.Common;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Chat.Server
{
    public class ClientHandler
    {
        private readonly Socket socket;
        private readonly List<ClientHandler> clients;
        private CommunicationHelper helper;

        public ClientHandler(Socket socket, List<ClientHandler> clients)
        {
            this.socket = socket;
            this.clients = clients;
            Helper = new CommunicationHelper(socket);
        }

        public CommunicationHelper Helper { get => helper; private set => helper = value; }
        public string Username { get; private set; }

        internal void HandleRequests()
        {
            try
            {
                bool kraj = false;
                while (!kraj)
                {
                    Message message = Helper.Receive<Message>();
                    switch (message.Operation)
                    {
                        case Operation.Login:
                            LoginUser(message);
                            break;
                        case Operation.SendToAll:
                            SendToAll(message);
                            break;
                        case Operation.End:
                            SendToAllExcept(message);
                            kraj = true;
                            break;
                        default:
                            break;
                    }

                }
            }
            catch (IOException ex)
            {
                Debug.WriteLine(ex.Message);
            }
            finally
            {
                if (socket != null && socket.Connected)
                {
                    socket.Shutdown(SocketShutdown.Both);
                    socket.Close();
                }
                clients.Remove(this);
               
            }

        }

        private void LoginUser(Message message)
        {
            bool postoji = false;
            foreach(ClientHandler client in clients)
            {
                if (client.Username == message.Name)
                {
                    postoji = true;
                }
            }

            if (!postoji)
            {
                Username = message.Name;
                Message odgovor = new Message
                {
                    IsSuccessful = true,
                };
                helper.Send(odgovor);

                Message porukaKaSvima = new Message();
                SendToAll(porukaKaSvima);
            }
            else
            {
                Message odgovor = new Message
                {
                    IsSuccessful = false,
                    ErrorText = "Korisnicko ime je zauzeto!"
                };
                helper.Send(odgovor);
            }
        }

        private void SendToAll(Message m)
        {
            m.Name = Username;
            foreach (ClientHandler client in clients)
            {
               if(client.Username != null) client.Helper.Send(m);
            }
        }

        private void SendToAllExcept(Message m)
        {
            m.Name = Username;
            m.Operation = Operation.OdjavljenKlijent;
            foreach (ClientHandler client in clients)
            {
                if (client != this && client.Username != null) client.Helper.Send(m);
            }
        }

        public void Close()
        {
            if (socket != null && socket.Connected)
            {
                socket.Shutdown(SocketShutdown.Both);
                socket.Close();
            }


        }

    }
}
