﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class FrmServer : Form
    {
        private Server server = new Server();
        public FrmServer()
        {
            InitializeComponent();
            cmbIgre.DataSource = Kontroler.Instance.VratiSveIgre();
            cmbIgre.DisplayMember = "Naziv";

            
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            dgvIgraci.DataSource = new BindingList<ClientHandler>(server.Klijenti);
        }

        private void btnPokreni_Click(object sender, EventArgs e)
        {
            Igra igra = (Igra)cmbIgre.SelectedItem;
            if (!int.TryParse(txtBrojIgraca.Text, out int brojIgraca) || brojIgraca > 4 || brojIgraca < 1)
            {
                MessageBox.Show("Broj igraca nije dobar!");
                return;
            }
            btnPokreni.Enabled = false;
            Thread nit = new Thread(() => { server.PokreniIgru(igra, brojIgraca); });
            nit.Start();
            MessageBox.Show("Server je uspesno pokrenut!");
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 1000;
            timer.Tick += Timer_Tick;
            timer.Start();
            Thread test = new Thread(() => { Test(nit); });
            test.Start();
           
        }

        private void Test(Thread nit)
        {
            nit.Join();
            Invoke(new Action(() => {
                //Application.DoEvents();
                btnPokreni.Enabled = true; }));

        }

        private void FrmServer_FormClosed(object sender, FormClosedEventArgs e)
        {
            OdgovorOdServera o = new OdgovorOdServera();
            o.Signal = Signal.Pad;
            server.PosaljiOdg(o);
            Environment.Exit(0);
        }
    }

    
}

