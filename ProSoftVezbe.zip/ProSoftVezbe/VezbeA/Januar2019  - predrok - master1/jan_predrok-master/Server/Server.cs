﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    public class Server
    {
        private Socket osluskujuciSoket;
        private List<ClientHandler> klijenti = new List<ClientHandler>();
        Igra i;
        
     
        public Server()
        {
            osluskujuciSoket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            osluskujuciSoket.Bind(new IPEndPoint(IPAddress.Parse("127.0.0.1"), 9090));
            osluskujuciSoket.Listen(5);
        }

        public List<ClientHandler> Klijenti { get => klijenti; set => klijenti = value; }

        public bool PokreniIgru(Igra igra, int brojIgraca)//3
        {
            i = igra;
            
            i.DatumVremePocetka= DateTime.Now;
            while (brojIgraca > 0)
            {
                Socket socket = osluskujuciSoket.Accept();
                ClientHandler igrac = new ClientHandler(socket, klijenti);
                if (igrac.PrijaviIgraca())
                {
                    klijenti.Add(igrac);
                    brojIgraca--;
                }
            }
            
            //igra pocinje!
            igra.Pitanja = Kontroler.Instance.VratiPitanjaZaIgru(igra);
            List<Thread> niti = new List<Thread>();
            foreach (ClientHandler igrac in klijenti)
            {
                Thread nit = new Thread(() => { igrac.PokreniIgruZaIgraca(igra); });
                niti.Add(nit);
                nit.Start();
            }
            foreach (Thread nit in niti)
            {
                nit.Join();
            }
            ProglasiPobednika();
            i.DatumVremeKraja= DateTime.Now;

            Kontroler.Instance.AzurirajIgru(i);




            klijenti.Clear();
            return true;
        }

        private void ProglasiPobednika()
        {
            klijenti = klijenti.OrderByDescending(k => k.Ukupno).ToList();

            ClientHandler pobednik  = klijenti.First();
            i.Pobednik = pobednik.ImeIgraca;

            foreach (ClientHandler h in klijenti)
            {
                h.ObjaviPobednika(pobednik.ImeIgraca, pobednik.Ukupno);
            }


        }

        internal void PosaljiOdg(OdgovorOdServera o)
        {
            foreach (ClientHandler h in klijenti)
            {
                h.PosaljiOdg(o);
            }
        }
    }
}
