﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    [Serializable]
    public class ZahtevOdKlijenta
    {
        public string KorisnickoIme { get; set; }
        public string Odgovor { get; set; }
    }
}
