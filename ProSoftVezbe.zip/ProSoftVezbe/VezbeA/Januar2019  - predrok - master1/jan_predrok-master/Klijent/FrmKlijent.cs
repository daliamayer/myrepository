﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class FrmKlijent : Form
    {
        private double brojPoena = 0;

        public FrmKlijent()
        {
            InitializeComponent();
            gbIgra.Enabled = false;
        }

        private void btnPrijava_Click(object sender, EventArgs e)
        {
            try
            {
                Komunikacija.Instance.PrijaviSe(txtKorisnickoIme.Text);
                MessageBox.Show("Cekam na pocetak igre!");
                gbPrijava.Enabled = false;
                gbIgra.Enabled = true;
                ProcitajPitanje();
                
            }
            catch (SocketException ex)
            {
                MessageBox.Show("Server nije pokrenut!");
                return;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ProcitajPitanje()
        {
            Console.WriteLine("citam pitanje");
            OdgovorOdServera odgovor = Komunikacija.Instance.ProcitajPorukuOdServera();
            Console.WriteLine("procitao sam pitanje");
            if(odgovor.Signal == Signal.Pad)
            {
                MessageBox.Show("Server je pao!!!!!!!!!!!!!!!");
                Komunikacija.Instance.Close();
                this.Dispose();
            }
            if (odgovor.Pobednik == null)
            {

                // SA MESSAGE BOX SE NE GOMILAJU KLIKOVI TJ SLANJE ODGOVORA SERVERU 
                // NE ZNAMO KAKO
                //MessageBox.Show("Procitano pitanje!");
         
                txtPitanje.Text = odgovor.TekstPitanja;
            }
            else
            {
                MessageBox.Show("Pobednik je " + odgovor.Pobednik + odgovor.Poeni);
                Komunikacija.Instance.Close();
                this.Dispose();
            }
        }

        private void Odgovori()
        {
            try
            {
                ZahtevOdKlijenta z = new ZahtevOdKlijenta { Odgovor = txtOdgovor.Text };
                Komunikacija.Instance.PosaljiPoruku(z);

                OdgovorOdServera odgovor = Komunikacija.Instance.ProcitajPorukuOdServera();
                if (odgovor.Signal == Signal.Pad)
                {
                    MessageBox.Show("Server je pao!!!!!!!!!!!!!!!");
                    Komunikacija.Instance.Close();
                    this.Dispose();
                }

               
                txtPorukaOdServera.Text = odgovor.PorukaOdServera;
                brojPoena += odgovor.Poeni;
                txtUkupanBrojPoena.Text = brojPoena.ToString();
            }

            catch (IOException ex)
            {

                throw;
            }
            
        }
      
        
        private void btnPosaljiOdgovor_Click(object sender, EventArgs e)
        {

                try
                {
                    btnPosaljiOdgovor.Enabled = false;
                    Odgovori(); //odmah   
                    ProcitajPitanje(); //zaglavljuje se
                    Application.DoEvents(); //!!!!! ENQUEUES SVE CLICK DOGADJAJE KOJI KAO
                                           //DA SU SE GOMILALI U btn.ENABLED=FALSE, da sve koji su se redjali
                                           //dok j dugme bilo disabled brise
                    btnPosaljiOdgovor.Enabled = true;

                }
                catch (IOException ex)
                {
                    MessageBox.Show("Server je pao!");
                    Komunikacija.Instance.Close();
                    this.Dispose();
                    return;
                }
            
            
            
        }

       
    }
}
