﻿
namespace Client
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gblogin = new System.Windows.Forms.GroupBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUsename = new System.Windows.Forms.TextBox();
            this.gbUnos = new System.Windows.Forms.GroupBox();
            this.lblKorisnik = new System.Windows.Forms.Label();
            this.btnOdjava = new System.Windows.Forms.Button();
            this.txtSrpskaRec = new System.Windows.Forms.TextBox();
            this.txtEngleskoZnacenje = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dgvZnacenja = new System.Windows.Forms.DataGridView();
            this.bntSacuvajURecnik = new System.Windows.Forms.Button();
            this.btnDodajZnacenje = new System.Windows.Forms.Button();
            this.btnObrisiZnacenje = new System.Windows.Forms.Button();
            this.dgvPoslednjeIzmene = new System.Windows.Forms.DataGridView();
            this.gblogin.SuspendLayout();
            this.gbUnos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvZnacenja)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPoslednjeIzmene)).BeginInit();
            this.SuspendLayout();
            // 
            // gblogin
            // 
            this.gblogin.Controls.Add(this.btnLogin);
            this.gblogin.Controls.Add(this.label1);
            this.gblogin.Controls.Add(this.txtUsename);
            this.gblogin.Location = new System.Drawing.Point(44, 24);
            this.gblogin.Name = "gblogin";
            this.gblogin.Size = new System.Drawing.Size(779, 120);
            this.gblogin.TabIndex = 0;
            this.gblogin.TabStop = false;
            this.gblogin.Text = "Login";
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(297, 76);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(183, 29);
            this.btnLogin.TabIndex = 2;
            this.btnLogin.Text = "Prijavi se";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Username";
            // 
            // txtUsename
            // 
            this.txtUsename.Location = new System.Drawing.Point(297, 36);
            this.txtUsename.Name = "txtUsename";
            this.txtUsename.Size = new System.Drawing.Size(425, 22);
            this.txtUsename.TabIndex = 0;
            // 
            // gbUnos
            // 
            this.gbUnos.Controls.Add(this.dgvPoslednjeIzmene);
            this.gbUnos.Controls.Add(this.btnObrisiZnacenje);
            this.gbUnos.Controls.Add(this.btnDodajZnacenje);
            this.gbUnos.Controls.Add(this.bntSacuvajURecnik);
            this.gbUnos.Controls.Add(this.dgvZnacenja);
            this.gbUnos.Controls.Add(this.label3);
            this.gbUnos.Controls.Add(this.label2);
            this.gbUnos.Controls.Add(this.txtEngleskoZnacenje);
            this.gbUnos.Controls.Add(this.txtSrpskaRec);
            this.gbUnos.Controls.Add(this.lblKorisnik);
            this.gbUnos.Controls.Add(this.btnOdjava);
            this.gbUnos.Location = new System.Drawing.Point(44, 170);
            this.gbUnos.Name = "gbUnos";
            this.gbUnos.Size = new System.Drawing.Size(1110, 520);
            this.gbUnos.TabIndex = 1;
            this.gbUnos.TabStop = false;
            this.gbUnos.Text = "Unos reci";
            // 
            // lblKorisnik
            // 
            this.lblKorisnik.AutoSize = true;
            this.lblKorisnik.Location = new System.Drawing.Point(1012, 38);
            this.lblKorisnik.Name = "lblKorisnik";
            this.lblKorisnik.Size = new System.Drawing.Size(46, 17);
            this.lblKorisnik.TabIndex = 1;
            this.lblKorisnik.Text = "label2";
            // 
            // btnOdjava
            // 
            this.btnOdjava.Location = new System.Drawing.Point(967, 457);
            this.btnOdjava.Name = "btnOdjava";
            this.btnOdjava.Size = new System.Drawing.Size(117, 35);
            this.btnOdjava.TabIndex = 0;
            this.btnOdjava.Text = "Odjavi se";
            this.btnOdjava.UseVisualStyleBackColor = true;
            this.btnOdjava.Click += new System.EventHandler(this.btnOdjava_Click);
            // 
            // txtSrpskaRec
            // 
            this.txtSrpskaRec.Location = new System.Drawing.Point(193, 48);
            this.txtSrpskaRec.Name = "txtSrpskaRec";
            this.txtSrpskaRec.Size = new System.Drawing.Size(243, 22);
            this.txtSrpskaRec.TabIndex = 2;
            // 
            // txtEngleskoZnacenje
            // 
            this.txtEngleskoZnacenje.Location = new System.Drawing.Point(193, 103);
            this.txtEngleskoZnacenje.Name = "txtEngleskoZnacenje";
            this.txtEngleskoZnacenje.Size = new System.Drawing.Size(243, 22);
            this.txtEngleskoZnacenje.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Srpska rec";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Englesko znacenje";
            // 
            // dgvZnacenja
            // 
            this.dgvZnacenja.AllowUserToAddRows = false;
            this.dgvZnacenja.AllowUserToDeleteRows = false;
            this.dgvZnacenja.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvZnacenja.Location = new System.Drawing.Point(16, 220);
            this.dgvZnacenja.Name = "dgvZnacenja";
            this.dgvZnacenja.ReadOnly = true;
            this.dgvZnacenja.RowHeadersWidth = 51;
            this.dgvZnacenja.RowTemplate.Height = 24;
            this.dgvZnacenja.Size = new System.Drawing.Size(393, 212);
            this.dgvZnacenja.TabIndex = 6;
            // 
            // bntSacuvajURecnik
            // 
            this.bntSacuvajURecnik.Location = new System.Drawing.Point(16, 458);
            this.bntSacuvajURecnik.Name = "bntSacuvajURecnik";
            this.bntSacuvajURecnik.Size = new System.Drawing.Size(174, 33);
            this.bntSacuvajURecnik.TabIndex = 7;
            this.bntSacuvajURecnik.Text = "Sacuvaj rec u recnik";
            this.bntSacuvajURecnik.UseVisualStyleBackColor = true;
            this.bntSacuvajURecnik.Click += new System.EventHandler(this.bntSacuvajURecnik_Click);
            // 
            // btnDodajZnacenje
            // 
            this.btnDodajZnacenje.Location = new System.Drawing.Point(36, 167);
            this.btnDodajZnacenje.Name = "btnDodajZnacenje";
            this.btnDodajZnacenje.Size = new System.Drawing.Size(121, 28);
            this.btnDodajZnacenje.TabIndex = 8;
            this.btnDodajZnacenje.Text = "Dodaj znacenje";
            this.btnDodajZnacenje.UseVisualStyleBackColor = true;
            this.btnDodajZnacenje.Click += new System.EventHandler(this.btnDodajZnacenje_Click);
            // 
            // btnObrisiZnacenje
            // 
            this.btnObrisiZnacenje.Location = new System.Drawing.Point(237, 167);
            this.btnObrisiZnacenje.Name = "btnObrisiZnacenje";
            this.btnObrisiZnacenje.Size = new System.Drawing.Size(121, 28);
            this.btnObrisiZnacenje.TabIndex = 9;
            this.btnObrisiZnacenje.Text = "Obrisi znacenje";
            this.btnObrisiZnacenje.UseVisualStyleBackColor = true;
            this.btnObrisiZnacenje.Click += new System.EventHandler(this.btnObrisiZnacenje_Click);
            // 
            // dgvPoslednjeIzmene
            // 
            this.dgvPoslednjeIzmene.AllowUserToAddRows = false;
            this.dgvPoslednjeIzmene.AllowUserToDeleteRows = false;
            this.dgvPoslednjeIzmene.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPoslednjeIzmene.Location = new System.Drawing.Point(519, 220);
            this.dgvPoslednjeIzmene.Name = "dgvPoslednjeIzmene";
            this.dgvPoslednjeIzmene.ReadOnly = true;
            this.dgvPoslednjeIzmene.RowHeadersWidth = 51;
            this.dgvPoslednjeIzmene.RowTemplate.Height = 24;
            this.dgvPoslednjeIzmene.Size = new System.Drawing.Size(539, 215);
            this.dgvPoslednjeIzmene.TabIndex = 10;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1166, 702);
            this.Controls.Add(this.gbUnos);
            this.Controls.Add(this.gblogin);
            this.Name = "FrmMain";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmMain_FormClosed);
            this.gblogin.ResumeLayout(false);
            this.gblogin.PerformLayout();
            this.gbUnos.ResumeLayout(false);
            this.gbUnos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvZnacenja)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPoslednjeIzmene)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gblogin;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUsename;
        private System.Windows.Forms.GroupBox gbUnos;
        private System.Windows.Forms.Button btnOdjava;
        private System.Windows.Forms.Label lblKorisnik;
        private System.Windows.Forms.Button btnObrisiZnacenje;
        private System.Windows.Forms.Button btnDodajZnacenje;
        private System.Windows.Forms.Button bntSacuvajURecnik;
        private System.Windows.Forms.DataGridView dgvZnacenja;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtEngleskoZnacenje;
        private System.Windows.Forms.TextBox txtSrpskaRec;
        private System.Windows.Forms.DataGridView dgvPoslednjeIzmene;
    }
}

