﻿using Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class FrmMain : Form
    {
        private string Username;
        Thread nit;
        List<EngleskaRec> engleskaZnacenja = new List<EngleskaRec>();
        List<Izvestaj> zaIzmenu = new List<Izvestaj>();
        int brojac = 0;
        public FrmMain()
        {
            InitializeComponent();
            gbUnos.Visible = false;
            dgvZnacenja.DataSource = new List<EngleskaRec>();
            dgvZnacenja.Columns[1].Visible = false;
            dgvPoslednjeIzmene.DataSource = new List<Izvestaj>();
            dgvPoslednjeIzmene.Columns[0].Width = 500;
            


        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                Communication.Instance.Connect();
                Poruka p = new Poruka();
                p.Korisnik = txtUsename.Text;
                p.Operation = Operation.Login;
                Communication.Instance.Send(p);
                Poruka odg = Communication.Instance.ReadMessage();
                if (!odg.IsSuccessful)
                {
                    MessageBox.Show(odg.ErrorText);
                    txtUsename.Text = "";
                    return;

                }
                Username = txtUsename.Text;
                lblKorisnik.Text = Username;
                gblogin.Visible = false;
                gbUnos.Visible = true;
                InitListener();
            }
            catch (SocketException ex)
            {
                MessageBox.Show("Server nije pokrenut!");
                return;

            }
            catch (IOException ex)
            {
                MessageBox.Show("Server je pao!");

            }


        }

        private void InitListener()
        {
            nit = new Thread(CitajPoruke);
            nit.IsBackground = true;
            nit.Start();
        }

        private void CitajPoruke()
        {
            try
            {
                while (true)
                {
                    Poruka m = Communication.Instance.ReadMessage();

                    switch (m.Operation)
                    {
                        case Common.Operation.End:
                            Invoke(new Action(() => {
                                MessageBox.Show("Server je pao!");
                                gbUnos.Visible = false;
                                gblogin.Visible = true;
                            }));
                            break;
                        case Common.Operation.DodataRec:
                            Invoke(new Action(() => {
                                if(m.StaraZnacenja==null && m.NovaZnacenja == null)
                                {
                                    string s = Ispis1(m.RecZaRecnik);
                                    Izvestaj i = new Izvestaj
                                    {
                                        PoslednjeIzmene = s
                                    };
                                    zaIzmenu.Insert(0, i);
                                    if(zaIzmenu.Count > 3)
                                    {
                                        zaIzmenu.RemoveAt(3);
                                    }
                                    dgvPoslednjeIzmene.DataSource = null;
                                    dgvPoslednjeIzmene.DataSource = zaIzmenu;
                                    dgvPoslednjeIzmene.Columns[0].Width = 500;


                                }
                                else
                                {
                                    string s = Ispis2(m.RecZaRecnik, m.NovaZnacenja, m.StaraZnacenja);
                                    Izvestaj i = new Izvestaj
                                    {
                                        PoslednjeIzmene = s
                                    };
                                    zaIzmenu.Insert(0, i);
                                    if (zaIzmenu.Count > 3)
                                    {
                                        zaIzmenu.RemoveAt(3);
                                    }
                                    dgvPoslednjeIzmene.DataSource = null;
                                    dgvPoslednjeIzmene.DataSource = zaIzmenu;
                                    dgvPoslednjeIzmene.Columns[0].Width = 500;
                                }
                            }));
                            break;

                        default:
                            break;
                    }
                }

            }
            catch (Exception ex)
            {
                //nit.Abort();
                Console.WriteLine(ex.Message);

                
            }
        }

        private string Ispis2(SrpskaRec rec, List<EngleskaRec> novaZnacenja, List<EngleskaRec> staraZnacenja)
        {
            string pom = "Nova rec: " + rec.Rec + ", novo znacenje: ";

            foreach (EngleskaRec e in novaZnacenja)
            {
                pom += e.Rec + ", ";
            }

            pom += "korisnik: " + rec.KoJeUneo;
            pom += ", ostala znacenja: ";

            foreach (EngleskaRec e in staraZnacenja)
            {
                pom += e.Rec + ", ";
            }

            int duzina = pom.Length;

            return pom;
        }

        private string Ispis1(SrpskaRec rec)
        {
            string pom = "Nova rec: " + rec.Rec+", znacenje: ";

            foreach (EngleskaRec e in rec.EngleskaZnacenja)
            {
                pom += e.Rec + ", ";
            }

            pom += "korisnik: "+ rec.KoJeUneo;

            return pom;
            
        }

        private void Odjava()
        {

            Poruka p = new Poruka();
            p.Operation = Operation.End;
            p.Korisnik = Username;
            Communication.Instance.Send(p);
            Communication.Instance.Disconnect();
        }

        private void btnOdjava_Click(object sender, EventArgs e)
        {
            Odjava();
            gblogin.Visible = true;
            gbUnos.Visible = false;
        }

        private void FrmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            Odjava();
            Environment.Exit(0);
        }

        private void btnDodajZnacenje_Click(object sender, EventArgs e)
        {
            string engl = txtEngleskoZnacenje.Text;
            if(string.IsNullOrEmpty(engl) || string.IsNullOrWhiteSpace(engl))
            {
                MessageBox.Show("Morate uneti znacenje!");
                return;
            }
            
            EngleskaRec en = new EngleskaRec
            {
                Rec = engl,
                KoJeUneo = Username
            };
            if(engleskaZnacenja!= null && engleskaZnacenja.Contains(en))
            {
                MessageBox.Show("Vec ste uneli dato znacenje!");
                return;
            }
            txtEngleskoZnacenje.Text = "";
            engleskaZnacenja.Add(en);
            dgvZnacenja.DataSource = null;
            dgvZnacenja.DataSource = engleskaZnacenja;
            dgvZnacenja.Columns[1].Visible = false;

        }

        private void btnObrisiZnacenje_Click(object sender, EventArgs e)
        {
            if(dgvZnacenja.SelectedRows == null || dgvZnacenja.SelectedRows.Count==0)
            {
                MessageBox.Show("Morate selektovati red da biste ga obrisali!");
                return;
            }

            EngleskaRec en = (EngleskaRec)dgvZnacenja.SelectedRows[0].DataBoundItem;
            engleskaZnacenja.Remove(en);
            dgvZnacenja.DataSource = null;
            dgvZnacenja.DataSource = engleskaZnacenja;
            dgvZnacenja.Columns[1].Visible = false;
        }

        private void bntSacuvajURecnik_Click(object sender, EventArgs e)
        {
            string srp = txtSrpskaRec.Text;
            if (string.IsNullOrEmpty(srp) || string.IsNullOrWhiteSpace(srp))
            {
                MessageBox.Show("Morate uneti rec na srpskom!");
                return;
            }
            if(engleskaZnacenja == null || engleskaZnacenja.Count == 0)
            {
                MessageBox.Show("Morate uneti bar jedno englesko znacenje!");
                return;
            }

            SrpskaRec s = new SrpskaRec
            {
                Rec = srp,
                KoJeUneo = Username,
                EngleskaZnacenja = engleskaZnacenja
            };

            Poruka p = new Poruka();
            p.RecZaRecnik = s;
            p.Operation = Operation.DodajURecnik;
            p.Korisnik = Username;
            Communication.Instance.Send(p);
            txtSrpskaRec.Text = "";
            txtEngleskoZnacenje.Text = "";
            engleskaZnacenja.Clear();
            dgvZnacenja.DataSource = null;
            dgvZnacenja.DataSource = engleskaZnacenja;
            dgvZnacenja.Columns[1].Visible = false;
        }
    }
}
