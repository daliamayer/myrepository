﻿using Common;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class ClientHandler
    {
        private readonly Socket socket;
        private readonly List<ClientHandler> clients;
        private CommunicationHelper helper;
        FrmServer serverForma;

        public ClientHandler(Socket socket, List<ClientHandler> clients, FrmServer forma)
        {
            this.socket = socket;
            this.clients = clients;
            Helper = new CommunicationHelper(socket);
            serverForma = forma;
        }

        public CommunicationHelper Helper { get => helper; private set => helper = value; }
        public string Username { get; private set; }

        internal void HandleRequests()
        {
            try
            {
                bool kraj = false;
                while (!kraj)
                {
                    Poruka message = Helper.Receive<Poruka>();
                    switch (message.Operation)
                    {
                        case Operation.Login:
                            LoginUser(message);
                            break;
                        case Operation.DodajURecnik:
                            DodajURecnik(message);
                            Controller.Instance.NapuniRecnik();
                            serverForma.Osvezi();
                            break;
                        case Operation.End:
                            OdjavljenKlijent();
                            kraj = true;
                            break;
                        default:
                            break;
                    }

                }
            }
            catch (IOException ex)
            {
                Debug.WriteLine(ex.Message);
            }
            finally
            {
                if (socket != null && socket.Connected)
                {
                    socket.Shutdown(SocketShutdown.Both);
                    socket.Close();
                }
                clients.Remove(this);

            }

        }

        private void DodajURecnik(Poruka message)
        {
            SrpskaRec s = message.RecZaRecnik;
            List<EngleskaRec> novaZnacenja = new List<EngleskaRec>();
            //List<EngleskaRec> staraZnacenja = new List<EngleskaRec>();
            bool postoji = false;

            foreach (SrpskaRec item in Controller.Instance.recnik)
            {
                if(item.Equals(s))
                {
                    foreach (EngleskaRec e in s.EngleskaZnacenja)
                    {
                        if(item.EngleskaZnacenja.Contains(e))
                        {
                            continue;
                        }
                        else
                        {
                            novaZnacenja.Add(e);
                        }
                       
                    }
                    if(novaZnacenja == null || novaZnacenja.Count == 0)
                    {
                        return;
                    }
                    SendToAll(s, item.EngleskaZnacenja, novaZnacenja);
                    item.EngleskaZnacenja.AddRange(novaZnacenja);
                    return;
                }
            }

            Controller.Instance.recnik.Add(s);

            SendToAll(s);

        }

        private void OdjavljenKlijent()
        {
            if (socket != null && socket.Connected)
            {
                socket.Shutdown(SocketShutdown.Both);
                socket.Close();
            }
            clients?.Remove(this);
        }

        private void LoginUser(Poruka message)
        {
            bool postojiUBazi = false;
           
            foreach (Korisnik k in Controller.Instance.korisnici)
            {
                if (k.KorisnickoIme == message.Korisnik)
                {
                    postojiUBazi = true;
                    break;
                }
            }

            if (!postojiUBazi)
            {
                Poruka odgovor = new Poruka
                {
                    IsSuccessful = false,
                    ErrorText = "Korisnik ne postoji u bazi!"
                };
                
                helper.Send(odgovor);


            }
            else
            {
                Username = message.Korisnik;
                Poruka odgovor = new Poruka
                {
                    IsSuccessful = true,
                };
                clients.Add(this);
                helper.Send(odgovor);
            }
        }

        private void SendToAll(SrpskaRec m, List<EngleskaRec> staraZnacenja = null, List<EngleskaRec> novaZnacenja = null)
        {
            Poruka p = new Poruka();
            p.RecZaRecnik = m;
            p.NovaZnacenja = novaZnacenja;
            p.StaraZnacenja = staraZnacenja;
            p.Operation = Operation.DodataRec;
            
            foreach (ClientHandler client in clients)
            {
                if (client != null) client.Helper.Send(p);
            }
        }

        private void SendToAllExcept(Poruka m)
        {
            //m.Name = Username;
            //m.Operation = Operation.OdjavljenKlijent;
            //foreach (ClientHandler client in clients)
            //{
            //    if (client != this && client.Username != null) client.Helper.Send(m);
            //}
        }

        public void Close()
        {
            if (socket != null && socket.Connected)
            {
                socket.Shutdown(SocketShutdown.Both);
                socket.Close();
            }
            


        }
    }
}
