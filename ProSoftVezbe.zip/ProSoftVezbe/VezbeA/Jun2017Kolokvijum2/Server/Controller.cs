﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class Controller
    {
        private static Controller instance;

        public List<Korisnik> korisnici = new List<Korisnik>()
        {
            new Korisnik
            {
                 KorisnickoIme="pera",
                 Ime="Pera",
                 Prezime="Peric"
            },
            new Korisnik
            {
                 KorisnickoIme="mika",
                 Ime="Mika",
                 Prezime="Mikic"
            },
            new Korisnik
            {
                 KorisnickoIme="zika",
                 Ime="Zika",
                 Prezime="Zikic"
            },
            new Korisnik
            {
                 KorisnickoIme="maja",
                 Ime="Maja",
                 Prezime="Petrovic"
            },
            new Korisnik
            {
                 KorisnickoIme="dea",
                 Ime="Andrea",
                 Prezime="Pesic"
            }

        };

        public List<SrpskaRec> recnik = new List<SrpskaRec>()
        {
            new SrpskaRec
            {
                Rec="konj",
                KoJeUneo="SERVER",
                EngleskaZnacenja=new List<EngleskaRec>()
                {
                    new EngleskaRec
                    {
                        KoJeUneo="SERVER",
                        Rec="horse"
                    },
                    new EngleskaRec
                    {
                        KoJeUneo="SERVER",
                        Rec="equine"
                    },

                }
            },
            new SrpskaRec
            {
                Rec="profesor",
                KoJeUneo="SERVER",
                EngleskaZnacenja=new List<EngleskaRec>()
                {
                    new EngleskaRec
                    {
                        KoJeUneo="SERVER",
                        Rec="professor"
                    },
                    new EngleskaRec
                    {
                        KoJeUneo="SERVER",
                        Rec="academic"
                    },

                }
            },
            new SrpskaRec
            {
                Rec="sto",
                KoJeUneo="SERVER",
                EngleskaZnacenja=new List<EngleskaRec>()
                {
                    new EngleskaRec
                    {
                        KoJeUneo="SERVER",
                        Rec="table"
                    },
                    new EngleskaRec
                    {
                        KoJeUneo="SERVER",
                        Rec="hundred"
                    },

                }
            },
            new SrpskaRec
            {
                Rec="telefon",
                KoJeUneo="SERVER",
                EngleskaZnacenja=new List<EngleskaRec>()
                {
                    new EngleskaRec
                    {
                        KoJeUneo="SERVER",
                        Rec="mobile"
                    },
                    new EngleskaRec
                    {
                        KoJeUneo="SERVER",
                        Rec="cell"
                    },
                    new EngleskaRec
                    {
                        KoJeUneo="SERVER",
                        Rec="phone"
                    },

                }
            }
        };

        public List<StavkaRecnika> stavkeRecnika = new List<StavkaRecnika>();

        public void NapuniRecnik()
        {
            stavkeRecnika.Clear();
            foreach (SrpskaRec item in recnik)
            {
                stavkeRecnika.Add(new StavkaRecnika { SRB = item });
            }
        }

        


        private Controller()
        {
            
        }
        public static Controller Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Controller();
                }
                return instance;
            }
        }
    }
}
