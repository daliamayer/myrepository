﻿
namespace Server
{
    partial class FrmServer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPokreni = new System.Windows.Forms.Button();
            this.btnZaustavi = new System.Windows.Forms.Button();
            this.gbRecnik = new System.Windows.Forms.GroupBox();
            this.dgvRecnik = new System.Windows.Forms.DataGridView();
            this.gbRecnik.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRecnik)).BeginInit();
            this.SuspendLayout();
            // 
            // txtStatus
            // 
            this.txtStatus.Enabled = false;
            this.txtStatus.Location = new System.Drawing.Point(263, 35);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(431, 22);
            this.txtStatus.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(94, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Status";
            // 
            // btnPokreni
            // 
            this.btnPokreni.Location = new System.Drawing.Point(124, 97);
            this.btnPokreni.Name = "btnPokreni";
            this.btnPokreni.Size = new System.Drawing.Size(144, 34);
            this.btnPokreni.TabIndex = 2;
            this.btnPokreni.Text = "Pokreni server";
            this.btnPokreni.UseVisualStyleBackColor = true;
            this.btnPokreni.Click += new System.EventHandler(this.btnPokreni_Click);
            // 
            // btnZaustavi
            // 
            this.btnZaustavi.Location = new System.Drawing.Point(533, 97);
            this.btnZaustavi.Name = "btnZaustavi";
            this.btnZaustavi.Size = new System.Drawing.Size(143, 34);
            this.btnZaustavi.TabIndex = 3;
            this.btnZaustavi.Text = "Zaustavi server";
            this.btnZaustavi.UseVisualStyleBackColor = true;
            this.btnZaustavi.Click += new System.EventHandler(this.btnZaustavi_Click);
            // 
            // gbRecnik
            // 
            this.gbRecnik.Controls.Add(this.dgvRecnik);
            this.gbRecnik.Location = new System.Drawing.Point(35, 159);
            this.gbRecnik.Name = "gbRecnik";
            this.gbRecnik.Size = new System.Drawing.Size(905, 394);
            this.gbRecnik.TabIndex = 4;
            this.gbRecnik.TabStop = false;
            this.gbRecnik.Text = "Recnik SRB-ENG";
            // 
            // dgvRecnik
            // 
            this.dgvRecnik.AllowUserToAddRows = false;
            this.dgvRecnik.AllowUserToDeleteRows = false;
            this.dgvRecnik.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRecnik.Location = new System.Drawing.Point(24, 37);
            this.dgvRecnik.Name = "dgvRecnik";
            this.dgvRecnik.ReadOnly = true;
            this.dgvRecnik.RowHeadersWidth = 51;
            this.dgvRecnik.RowTemplate.Height = 24;
            this.dgvRecnik.Size = new System.Drawing.Size(859, 351);
            this.dgvRecnik.TabIndex = 0;
            // 
            // FrmServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(974, 577);
            this.Controls.Add(this.gbRecnik);
            this.Controls.Add(this.btnZaustavi);
            this.Controls.Add(this.btnPokreni);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtStatus);
            this.Name = "FrmServer";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmServer_FormClosed);
            this.gbRecnik.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRecnik)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPokreni;
        private System.Windows.Forms.Button btnZaustavi;
        private System.Windows.Forms.GroupBox gbRecnik;
        private System.Windows.Forms.DataGridView dgvRecnik;
    }
}

