﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    [Serializable]
    public class EngleskaRec
    {
        public string Rec { get; set; }
        public string KoJeUneo { get; set; }
        public override string ToString()
        {
            return Rec + "(" + KoJeUneo + ")";
        }
        public override bool Equals(object obj)
        {
            if (obj is EngleskaRec e)
                return e.Rec == this.Rec;
            return false;
        }
    }
}
