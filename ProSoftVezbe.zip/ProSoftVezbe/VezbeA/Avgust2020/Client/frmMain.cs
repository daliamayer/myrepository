﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Common;

namespace Client
{
    public partial class frmMain : Form
    {
        private List<Common.Message> primljenePoruke = new List<Common.Message>();
        private string korisnickoIme;
        public frmMain()
        {
            InitializeComponent();
            gbSlanje.Visible = false;
            gbPrimljenePoruke.Visible = false;
               
            try
                {
                    Communication.Instance.Connect();


                }

                catch (SocketException ex)
                {
                    MessageBox.Show(ex.Message);
                    throw;
                }

            
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            try
            {
                string username = txtUsername.Text;
                Common.Message m = new Common.Message();
                m.Operacija = Common.Operacija.Login;
                m.KorisnikOd = username;
                Communication.Instance.Send(m);
                Common.Message prijem = Communication.Instance.ReadMessage();
                if (prijem.IsSuccessful)
                {
                    MessageBox.Show("Uspesno ste se prijavili");
                    korisnickoIme = username;
                    testLabela.Text = korisnickoIme;
                    gbLogIn.Visible = false;
                    gbSlanje.Visible = true;
                    gbPrimljenePoruke.Visible = true;
                    dgvSvePoruke.DataSource = new List<Common.Message>();
                    dgvSvePoruke.Columns[0].Visible = false;
                    dgvSvePoruke.Columns[2].Visible = false;
                    dgvSvePoruke.Columns[5].Visible = false;
                    dgvSvePoruke.Columns[6].Visible = false;
                    dgvSvePoruke.Columns[7].Visible = false;
                    dgvSvePoruke.Columns[8].Visible = false;

                    InitListener();
                    return;
                }

                MessageBox.Show("Niste se uspesno prijavili. Promenite username i probajte ponovo!");
            }
            catch (IOException ex)
            {

                MessageBox.Show("Server je pao!");
                //this.Dispose();
                Environment.Exit(0);
                
            }
            

        }

        private void InitListener()
        {
            Thread nit = new Thread(CitajPoruke);
            nit.Start();
            nit.IsBackground = true;
        }

        private void CitajPoruke()
        {
            try
            {
                while (true)
                {
                    Common.Message m = Communication.Instance.ReadMessage();

                    switch (m.Operacija)
                    {
                        
                        case Common.Operacija.SendToAll:
                            //Invoke(new Action(() => { rtbMessages.AppendText(Environment.NewLine + m.Name + ": " + m.Text); }));
                            break;
                        //case Common.Operacija.End:
                        //    Invoke(new Action(() => { MessageBox.Show("Server je pao!"); Environment.Exit(0); }));
                        //    break;
                        case Common.Operacija.PorukaOdservera:
                            primljenePoruke.Add(m);
                            Invoke(new Action(() => {
                                txtPoslednjaPoruka.Text = m.Tekst;
                                dgvSvePoruke.DataSource = null;
                                dgvSvePoruke.DataSource = primljenePoruke;
                                dgvSvePoruke.Columns[0].Visible = false;
                                dgvSvePoruke.Columns[2].Visible = false;
                                dgvSvePoruke.Columns[5].Visible = false;
                                dgvSvePoruke.Columns[6].Visible = false;
                                dgvSvePoruke.Columns[7].Visible = false;
                                dgvSvePoruke.Columns[8].Visible = false;
                            }));
                            break;
                        case Common.Operacija.NijeAktivan:
                            Invoke(new Action(() => {
                                MessageBox.Show(m.Tekst);
                            }));
                            break;
                        case Common.Operacija.StiglaPoruka:
                            primljenePoruke.Add(m);
                            Invoke(new Action(() => {
                                txtPoslednjaPoruka.Text = m.Tekst;
                                dgvSvePoruke.DataSource = null;
                                dgvSvePoruke.DataSource = primljenePoruke;
                                dgvSvePoruke.Columns[0].Visible = false;
                                dgvSvePoruke.Columns[2].Visible = false;
                                dgvSvePoruke.Columns[5].Visible = false;
                                dgvSvePoruke.Columns[6].Visible = false;
                                dgvSvePoruke.Columns[7].Visible = false;
                                dgvSvePoruke.Columns[8].Visible = false;

                            }));
                            break;

                        default:
                            break;
                    }
                }

            }
            catch (IOException ex)
            {
                MessageBox.Show("Server je pao!");
                //this.Dispose();
                Environment.Exit(0);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnPosalji_Click(object sender, EventArgs e)
        {
            try
            {
                Common.Message m = new Common.Message();
                m.KorisnikOd = korisnickoIme;
                m.KorisnikZa = txtImeKorisnika.Text;
                m.Tekst = txtTekst.Text;
                m.DatumVreme = DateTime.Now;
                m.Operacija = Operacija.PorukaZa;
                Communication.Instance.Send(m);



            }
            catch (IOException ex)
            {

                MessageBox.Show("Server je pao!");
                //this.Dispose();
                Environment.Exit(0);
            }
        }

        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
               
                Common.Message message = new Common.Message { Operacija = Common.Operacija.End,RequestObject=primljenePoruke};
                Communication.Instance.Send(message);
                Environment.Exit(0); //proveri kad  se  baca "error creating window handle"??
                //this.Dispose();
            }
            catch (IOException ex)
            {

                return;
            }
            
        }
    }
}
