﻿
namespace Client
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbLogIn = new System.Windows.Forms.GroupBox();
            this.gbSlanje = new System.Windows.Forms.GroupBox();
            this.gbPrimljenePoruke = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.btnLogIn = new System.Windows.Forms.Button();
            this.txtImeKorisnika = new System.Windows.Forms.TextBox();
            this.txtTekst = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnPosalji = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPoslednjaPoruka = new System.Windows.Forms.TextBox();
            this.dgvSvePoruke = new System.Windows.Forms.DataGridView();
            this.testLabela = new System.Windows.Forms.Label();
            this.gbLogIn.SuspendLayout();
            this.gbSlanje.SuspendLayout();
            this.gbPrimljenePoruke.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSvePoruke)).BeginInit();
            this.SuspendLayout();
            // 
            // gbLogIn
            // 
            this.gbLogIn.Controls.Add(this.btnLogIn);
            this.gbLogIn.Controls.Add(this.txtUsername);
            this.gbLogIn.Controls.Add(this.label1);
            this.gbLogIn.Location = new System.Drawing.Point(23, 24);
            this.gbLogIn.Name = "gbLogIn";
            this.gbLogIn.Size = new System.Drawing.Size(619, 96);
            this.gbLogIn.TabIndex = 0;
            this.gbLogIn.TabStop = false;
            // 
            // gbSlanje
            // 
            this.gbSlanje.Controls.Add(this.testLabela);
            this.gbSlanje.Controls.Add(this.btnPosalji);
            this.gbSlanje.Controls.Add(this.label3);
            this.gbSlanje.Controls.Add(this.label2);
            this.gbSlanje.Controls.Add(this.txtTekst);
            this.gbSlanje.Controls.Add(this.txtImeKorisnika);
            this.gbSlanje.Location = new System.Drawing.Point(23, 126);
            this.gbSlanje.Name = "gbSlanje";
            this.gbSlanje.Size = new System.Drawing.Size(628, 161);
            this.gbSlanje.TabIndex = 1;
            this.gbSlanje.TabStop = false;
            this.gbSlanje.Text = "Slanje poruke";
            // 
            // gbPrimljenePoruke
            // 
            this.gbPrimljenePoruke.Controls.Add(this.dgvSvePoruke);
            this.gbPrimljenePoruke.Controls.Add(this.txtPoslednjaPoruka);
            this.gbPrimljenePoruke.Controls.Add(this.label4);
            this.gbPrimljenePoruke.Location = new System.Drawing.Point(23, 302);
            this.gbPrimljenePoruke.Name = "gbPrimljenePoruke";
            this.gbPrimljenePoruke.Size = new System.Drawing.Size(619, 291);
            this.gbPrimljenePoruke.TabIndex = 2;
            this.gbPrimljenePoruke.TabStop = false;
            this.gbPrimljenePoruke.Text = "Primljene poruke";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Username";
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(121, 39);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(259, 22);
            this.txtUsername.TabIndex = 1;
            // 
            // btnLogIn
            // 
            this.btnLogIn.Location = new System.Drawing.Point(430, 32);
            this.btnLogIn.Name = "btnLogIn";
            this.btnLogIn.Size = new System.Drawing.Size(148, 37);
            this.btnLogIn.TabIndex = 2;
            this.btnLogIn.Text = "Log In";
            this.btnLogIn.UseVisualStyleBackColor = true;
            this.btnLogIn.Click += new System.EventHandler(this.btnLogIn_Click);
            // 
            // txtImeKorisnika
            // 
            this.txtImeKorisnika.Location = new System.Drawing.Point(214, 32);
            this.txtImeKorisnika.Name = "txtImeKorisnika";
            this.txtImeKorisnika.Size = new System.Drawing.Size(195, 22);
            this.txtImeKorisnika.TabIndex = 0;
            // 
            // txtTekst
            // 
            this.txtTekst.Location = new System.Drawing.Point(214, 72);
            this.txtTekst.Name = "txtTekst";
            this.txtTekst.Size = new System.Drawing.Size(195, 22);
            this.txtTekst.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(54, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Kome saljem";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Poruka";
            // 
            // btnPosalji
            // 
            this.btnPosalji.Location = new System.Drawing.Point(214, 115);
            this.btnPosalji.Name = "btnPosalji";
            this.btnPosalji.Size = new System.Drawing.Size(195, 30);
            this.btnPosalji.TabIndex = 4;
            this.btnPosalji.Text = "Posalji poruku";
            this.btnPosalji.UseVisualStyleBackColor = true;
            this.btnPosalji.Click += new System.EventHandler(this.btnPosalji_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(118, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Poslednja poruka";
            // 
            // txtPoslednjaPoruka
            // 
            this.txtPoslednjaPoruka.Location = new System.Drawing.Point(272, 42);
            this.txtPoslednjaPoruka.Name = "txtPoslednjaPoruka";
            this.txtPoslednjaPoruka.Size = new System.Drawing.Size(265, 22);
            this.txtPoslednjaPoruka.TabIndex = 6;
            // 
            // dgvSvePoruke
            // 
            this.dgvSvePoruke.AllowUserToAddRows = false;
            this.dgvSvePoruke.AllowUserToDeleteRows = false;
            this.dgvSvePoruke.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSvePoruke.Location = new System.Drawing.Point(28, 89);
            this.dgvSvePoruke.Name = "dgvSvePoruke";
            this.dgvSvePoruke.ReadOnly = true;
            this.dgvSvePoruke.RowHeadersWidth = 51;
            this.dgvSvePoruke.RowTemplate.Height = 24;
            this.dgvSvePoruke.Size = new System.Drawing.Size(550, 181);
            this.dgvSvePoruke.TabIndex = 7;
            // 
            // testLabela
            // 
            this.testLabela.AutoSize = true;
            this.testLabela.Location = new System.Drawing.Point(497, 47);
            this.testLabela.Name = "testLabela";
            this.testLabela.Size = new System.Drawing.Size(46, 17);
            this.testLabela.TabIndex = 5;
            this.testLabela.Text = "label5";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 626);
            this.Controls.Add(this.gbPrimljenePoruke);
            this.Controls.Add(this.gbSlanje);
            this.Controls.Add(this.gbLogIn);
            this.Name = "frmMain";
            this.Text = "Chat Klijent";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            this.gbLogIn.ResumeLayout(false);
            this.gbLogIn.PerformLayout();
            this.gbSlanje.ResumeLayout(false);
            this.gbSlanje.PerformLayout();
            this.gbPrimljenePoruke.ResumeLayout(false);
            this.gbPrimljenePoruke.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSvePoruke)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbLogIn;
        private System.Windows.Forms.GroupBox gbSlanje;
        private System.Windows.Forms.GroupBox gbPrimljenePoruke;
        private System.Windows.Forms.Button btnLogIn;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPosalji;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTekst;
        private System.Windows.Forms.TextBox txtImeKorisnika;
        private System.Windows.Forms.DataGridView dgvSvePoruke;
        private System.Windows.Forms.TextBox txtPoslednjaPoruka;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label testLabela;
    }
}

