﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{

    public enum Operacija {
        Login,
        SendToAll,
        End,
        PorukaOdservera,
        PorukaZa,
        NijeAktivan,
        StiglaPoruka
    }
    [Serializable]
    public class Message
    {
        public int PorukaID { get; set; }
        public string KorisnikOd { get; set; }
        public string KorisnikZa { get; set; }
        public DateTime DatumVreme { get; set; }

        public string Tekst { get; set; }  

       public Operacija Operacija { get; set; }

        public bool IsSuccessful { get; set; }
        public string ErrorText { get; set; }
        public object RequestObject { get; set; }



    }
}
