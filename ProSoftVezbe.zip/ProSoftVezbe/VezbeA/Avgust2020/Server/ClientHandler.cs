﻿using Common;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class ClientHandler
    {

        private readonly Socket socket;
        private readonly List<ClientHandler> clients;
        private Common.CommunicationHelper helper;

        public ClientHandler(Socket socket, List<ClientHandler> clients)
        {
            this.socket = socket;
            this.clients = clients;
            Helper = new Common.CommunicationHelper(socket);
        }

        public Common.CommunicationHelper Helper { get => helper; private set => helper = value; }
        public string Username { get; private set; }

        internal void HandleRequests()
        {
            try
            {
                bool kraj = false;
                while (!kraj)
                {
                    Message message = Helper.Receive<Message>();
                    switch (message.Operacija)
                    {
                        case Operacija.Login:
                            LoginUser(message);
                            break;
                        case Operacija.SendToAll:
                            SendToAll(message);
                            break;
                        case Operacija.End:
                            Controller.Instance.SacuvajPoruke((List<Message>)message.RequestObject);
                            Close();
                            kraj = true;
                            break;
                        case Operacija.PorukaZa:
                            PosaljiDatom(message);
                            break;
                        default:
                            break;
                    }

                }
            }
            catch (IOException ex)
            {
                
                Debug.WriteLine(ex.Message);
            }
            finally
            {
                if (socket != null && socket.Connected)
                {
                    socket.Shutdown(SocketShutdown.Both);
                    socket.Close();
                }
                clients.Remove(this);

            }

        }

        private void PosaljiDatom(Message message)
        {
            bool postoji = false;
            foreach (ClientHandler client in clients)
            {
                if (client.Username == message.KorisnikZa)
                {
                    postoji = true;
                    break;
                }
            }

            if(!postoji)
            {
                Message m = new Message();
                m.Tekst = "Korisnik nije aktivan!";
                m.Operacija = Operacija.NijeAktivan;
                m.KorisnikOd = "Server";
                m.DatumVreme = DateTime.Now;
                helper.Send(m);
                return;
            }
            Message m1 = new Message();
            m1.Tekst = message.Tekst ;
            m1.Operacija = Operacija.StiglaPoruka;
            m1.KorisnikOd = message.KorisnikOd;
            m1.KorisnikZa = message.KorisnikZa;
            m1.DatumVreme = message.DatumVreme;



            foreach (ClientHandler client in clients)
            {
                if(client != null && client.Username == m1.KorisnikZa)
                {
                    client.Helper.Send(m1);
                    break;
                }
            }
            

        }

        private void LoginUser(Message message)
        {
            bool postoji = false;
            foreach (ClientHandler client in clients)
            {
                if (client.Username == message.KorisnikOd)
                {
                    postoji = true;
                }
            }

            if (!postoji)
            {
                Username = message.KorisnikOd;
                Message odgovor = new Message
                {
                    IsSuccessful = true,
                    Tekst = "Uspesno ste se prijavili",
                    KorisnikOd = "Server"
                };
               
                helper.Send(odgovor);

            
            }
            else
            {
                Message odgovor = new Message
                {
                    IsSuccessful = false,
                    ErrorText = "Korisnicko ime je zauzeto!",
                     KorisnikOd = "Server"
                };
                helper.Send(odgovor);
            }
        }

        private void SendToAll(Message m)
        {
            m.KorisnikOd = "Server";

            foreach (ClientHandler client in clients)
            {
                if (client != null) client.Helper.Send(m); //vidi ovo
            }
        }


        public void Close() //klijent se gasi
        {
            if (socket != null && socket.Connected)
            {
                socket.Shutdown(SocketShutdown.Both);
                socket.Close();
            }
            clients.Remove(this);

        }

    }
}

