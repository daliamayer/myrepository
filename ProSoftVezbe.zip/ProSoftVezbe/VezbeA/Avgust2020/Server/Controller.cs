﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class Controller
    {
        private static Controller instance;
        private Broker broker = new Broker();
        private Controller()
        {
        }

        public static Controller Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Controller();
                }
                return instance;
            }
        }

        internal void SacuvajPoruke(List<Message> requestObject)
        {
            try
            {
                broker.OpenConnection();

                broker.BeginTransaction();


                foreach (Message m in requestObject)
                {
                    broker.SacuvajPoruku(m);
                }


                broker.Commit();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                broker.Rollback();
            }
            finally
            {
                broker.CloseConnection();
            }
        }
    }
}
