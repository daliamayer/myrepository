﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    class Program
    {
       
             static void Main(string[] args)
        {
            Server server= new Server();
            bool kraj = false;

            

            try
            {
                server.Start();
                Thread nit = new Thread(server.HandleClients);
                nit.IsBackground = true;
                nit.Start();
                Console.WriteLine("Server je pokrenut!");
                
                while (!kraj)
                {
                    Console.WriteLine("Unesite poruku za aktivne korisnike: ");
                    string serverPor = Console.ReadLine();
                    server.SlanjeServerskePoruke(serverPor);
                    
                }
                Console.ReadKey();
            }
            catch (SocketException ex)
            {
                Debug.WriteLine(ex.Message);
               
            }

        }

        
    }
}

