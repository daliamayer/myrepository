﻿using Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class Broker
    {

        private SqlConnection connection;
        private SqlTransaction transaction;

        public Broker()
        {
            connection = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ProSoft-Avgust2020;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        }

        public void OpenConnection()
        {
            connection.Open();
        }

        public void CloseConnection()
        {
            if (connection != null && connection.State != ConnectionState.Closed)
                connection.Close();
        }
        public SqlCommand CreateCommand()
        {
            return new SqlCommand("", connection, transaction);
        }

        internal void SacuvajPoruku(Message m)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.Transaction = transaction;
            try
            {
                command.CommandText = "insert into Poruka values (@korOd, @korZa, @datVr, @tekst)";

                command.Parameters.AddWithValue("@korOd", m.KorisnikOd);
                command.Parameters.AddWithValue("@korZa", m.KorisnikZa);
                command.Parameters.AddWithValue("@datVr", m.DatumVreme);
                command.Parameters.AddWithValue("@tekst", m.Tekst);
                
                command.ExecuteNonQuery();


            }
            catch (SqlException ex)
            {
                Debug.WriteLine(ex.Message); return;
            }
        }

        public void BeginTransaction()
        {
            transaction = connection.BeginTransaction();
        }

        public void Commit()
        {
            transaction.Commit();
        }

        public void Rollback()
        {
            transaction.Rollback();
        }
    }
}
