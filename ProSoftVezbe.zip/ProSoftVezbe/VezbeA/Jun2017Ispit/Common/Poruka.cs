﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public enum Operation
    {
        Login, End,
        DodajURecnik,
        DodataRec,
        DaLiPostojiRec,
        Izmeni
    }
    [Serializable]
    public class Poruka
    {
        public Operation Operation { get; set; }
        public Korisnik Korisnik { get; set; }
        public bool IsSuccessful { get; set; }
        public string ErrorText { get; set; }

        public SrpskaRec RecZaRecnik { get; set; }
        public List<EngleskaRec> NovaZnacenja { get; set; }
        public List<EngleskaRec> StaraZnacenja { get; set; }


    }
}
