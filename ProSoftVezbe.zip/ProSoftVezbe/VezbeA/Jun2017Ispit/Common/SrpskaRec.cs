﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    [Serializable]
    public class SrpskaRec
    {
        public int ID { get; set; }
        public string Rec { get; set; }
        public Korisnik KoJeUneo { get; set; }
        public List<EngleskaRec> EngleskaZnacenja { get; set; }
        public override string ToString()
        {
            return Rec + "(" + KoJeUneo.KorisnickoIme + ")";
        }
        public override bool Equals(object obj)
        {
            if (obj is SrpskaRec e)
                return e.Rec.ToUpper() == this.Rec.ToUpper();
            return false;
        }
    }
}
