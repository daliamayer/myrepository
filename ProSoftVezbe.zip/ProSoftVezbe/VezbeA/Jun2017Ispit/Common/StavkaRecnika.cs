﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class StavkaRecnika  //samo za prikaz u data grid view
    {
        public SrpskaRec SRB { get; set; }
        public string ENG { 
            get 
            {
                string engleskaZnacenja = "";
                foreach (EngleskaRec item in SRB.EngleskaZnacenja)
                {
                    engleskaZnacenja += item + ";";
                }
                int duzina = engleskaZnacenja.Length;
                return engleskaZnacenja.Substring(0,duzina-1);
            } 
            set
            {

            }
        }
    }
}
