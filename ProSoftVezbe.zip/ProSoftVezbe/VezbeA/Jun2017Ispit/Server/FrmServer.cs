﻿using Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class FrmServer : Form
    {
        Server server;
        public FrmServer()
        {
            InitializeComponent();
            server = new Server(this);
            txtStatus.Text = "Server nije pokrenut!";
            btnZaustavi.Enabled = false;
            gbRecnik.Visible = false;
        }

        private void btnPokreni_Click(object sender, EventArgs e)
        {
            try
            {
                server.Start();

                Thread nit = new Thread(server.HandleClients);
                nit.IsBackground = true;
                nit.Start();
                txtStatus.Text = "Server je pokrenut!";
                btnPokreni.Enabled = false;
                btnZaustavi.Enabled = true;
                gbRecnik.Visible = true;
                
                dgvRecnik.DataSource = Controller.Instance.vratiStavkeRecnika();
               
                dgvRecnik.Columns[1].Width = 200;
                dgvRecnik.Columns[1].Width = 500;

            }
            catch (SocketException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnZaustavi_Click(object sender, EventArgs e)
        {
            server.Stop();
            btnZaustavi.Enabled = false;
            btnPokreni.Enabled = true;
            txtStatus.Text = "Server nije pokrenut!";
            gbRecnik.Visible = false;
        }

        internal void Osvezi()
        {
            Invoke(new Action(() => {
                dgvRecnik.DataSource = null;
                dgvRecnik.DataSource = Controller.Instance.vratiStavkeRecnika();
                dgvRecnik.Columns[1].Width = 200;
                dgvRecnik.Columns[1].Width = 500;

            }));
           
        }

        private void FrmServer_FormClosed(object sender, FormClosedEventArgs e)
        {
            server.Stop();
        }
    }
}
