﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class Controller
    {
        private static Controller instance;

        private Broker broker = new Broker();
     

        private Controller()
        {
            
        }

        internal List<Korisnik> vratiKorisnike()
        {
            try
            {
                broker.OpenConnection();
                return broker.vratiKorisnike();
            }
            finally
            {
                broker.CloseConnection();
            }
        }

        public static Controller Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Controller();
                }
                return instance;
            }
        }

        internal List<StavkaRecnika> vratiStavkeRecnika()
        {
            try
            {
                broker.OpenConnection();
                List<SrpskaRec> reci = broker.vratiReci();
                foreach (SrpskaRec s in reci)
                {
                    s.EngleskaZnacenja = broker.vratiZnacenja(s);
                }

                List<StavkaRecnika> stavkeRecnika = new List<StavkaRecnika>();

                foreach (SrpskaRec item in reci)
                {
                    stavkeRecnika.Add(new StavkaRecnika { SRB = item });
                }

                return stavkeRecnika;


            }
            finally
            {
                broker.CloseConnection();
            }
        }

        internal List<SrpskaRec> vratiReci()
        {
            try
            {
                broker.OpenConnection();
                List<SrpskaRec> reci = broker.vratiReci();
                foreach (SrpskaRec s in reci) {
                    s.EngleskaZnacenja = broker.vratiZnacenja(s);
                
                }
                return reci;
            }
            finally
            {
                broker.CloseConnection();
            }
        }

        internal void DodajNovuRec(SrpskaRec s)
        {
            try
            {
                broker.OpenConnection();
                broker.BeginTransaction();

                broker.DodajNovuRec(s);

                broker.Commit();
            }
            catch (Exception e)
            {
                broker.Rollback();
            }
            finally
            {
                broker.CloseConnection();
            }
        }

        internal void dodajZnacenje(SrpskaRec s, List<EngleskaRec> novaZnacenja)
        {
            try
            {
                broker.OpenConnection();
                broker.BeginTransaction();

                broker.DodajZnacenje(s,novaZnacenja,s.KoJeUneo);

                broker.Commit();
            }
            catch (Exception e)
            {
                broker.Rollback();
            }
            finally
            {
                broker.CloseConnection();
            }
        }

        internal void Izmeni(SrpskaRec srpska, Korisnik korisnik)
        {
            try
            {
                broker.OpenConnection();

                List<EngleskaRec> znacenjaBaza = broker.vratiZnacenja(srpska);
                List<EngleskaRec> znacenjaPromena = srpska.EngleskaZnacenja;
                
                broker.BeginTransaction();


                bool postoji;
                
                foreach (EngleskaRec e in znacenjaBaza) {
                    
                    postoji = false;
                    
                    foreach (EngleskaRec e1 in znacenjaPromena) {
                        if (e.RB == e1.RB && e.Rec == e1.Rec) { postoji = true; }
                        if (e.RB == e1.RB && e.Rec!=e1.Rec) { postoji = true;

                            broker.IzmeniZnacenje(srpska, e1,korisnik);
                        }
                    }
                    if (!postoji) {

                        broker.ObrisiZnacenje(srpska,e,korisnik);
                    }

                }

                //DODAVANJE NOVIH
                List<EngleskaRec> pomocna = new List<EngleskaRec>();
                foreach (EngleskaRec e in znacenjaPromena)
                {

                    if (e.RB == 0)
                    {
                        pomocna.Add(e);
                    }

                }
                broker.DodajZnacenje(srpska, pomocna,korisnik);






                broker.Commit();
            }
            catch (Exception e)
            {
                broker.Rollback();
            }
            finally
            {
                broker.CloseConnection();
            }
        }
    }
    }

