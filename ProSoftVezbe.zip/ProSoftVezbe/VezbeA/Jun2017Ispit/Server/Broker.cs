﻿using Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class Broker
    {
        private SqlConnection connection;
        private SqlTransaction transaction;

        public Broker()
        {
            connection = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ProSoft-Jul2017Ispit;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

        }

        public void OpenConnection()
        {

            connection.Open();
        }

        public void CloseConnection()
        {
            if (connection != null && connection.State != ConnectionState.Closed)
                connection.Close();
        }
        public void BeginTransaction()
        {
            transaction = connection.BeginTransaction();
        }

        public void Commit()
        {
            transaction.Commit();
        }

        public void Rollback()
        {
            transaction.Rollback();
        }

        internal List<Korisnik> vratiKorisnike()
        {
            List<Korisnik> manufacturers = new List<Korisnik>();
            SqlCommand command = new SqlCommand("", connection);
            command.CommandText = "SELECT * FROM Korisnik";
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Korisnik m = new Korisnik();
                    m.ID = (int)reader["ID"];
                    m.Ime = (string)reader["Ime"];
                    m.Prezime = (string)reader["Prezime"];
                    m.KorisnickoIme= (string)reader["Username"];
                    manufacturers.Add(m);
                }
            }
            return manufacturers;
        }

        internal List<EngleskaRec> vratiZnacenja(SrpskaRec s)
        {
            List<EngleskaRec> manufacturers = new List<EngleskaRec>();
            SqlCommand command = new SqlCommand("", connection);
            command.CommandText = $"SELECT * FROM EngleskaRec join Korisnik k on" +
                $" (KoJeUneo=k.ID) where SrpskaRec={s.ID}";
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    EngleskaRec m = new EngleskaRec();
                    m.SrpskaRec = new SrpskaRec { ID = (int)reader["SrpskaRec"] };   
                    m.RB = (int)reader["RB"];
                    m.Rec = (string)reader["Rec"];
                    m.KoJeUneo = new Korisnik
                    {
                        ID = (int)reader["KoJeUneo"],
                        KorisnickoIme= (string)reader["Username"]
                };
   
                    manufacturers.Add(m);
                }
            }
            return manufacturers;
        }

        internal void DodajZnacenje(SrpskaRec s, List<EngleskaRec> novaZnacenja,Korisnik k)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.Transaction = transaction;
            try
            {
                command.CommandText = $"select max(RB) from EngleskaRec where SrpskaRec={s.ID}";
                int maxRb = 0;
                try
                {
                    maxRb = (int)command.ExecuteScalar();
                }
                catch (Exception e) {
                    maxRb = 0;
                }
                foreach (EngleskaRec a in novaZnacenja)
                {

                    command = new SqlCommand("", connection, transaction);
                    command.CommandText = "insert into EngleskaRec (SrpskaRec,RB" +
                        ",Rec,KoJeUneo) values" +
                    " (@srpska, @rb, @rec,@uneo)";

                    command.Parameters.AddWithValue("@srpska", s.ID);
                    command.Parameters.AddWithValue("@rb", ++maxRb);
                    command.Parameters.AddWithValue("@rec", a.Rec);
                    command.Parameters.AddWithValue("@uneo",k.ID);

                    command.ExecuteNonQuery();

                }
            }
            catch (SqlException ex) { Console.WriteLine(ex.Message); }
            }

        internal void ObrisiZnacenje(SrpskaRec srpska, EngleskaRec e,Korisnik k)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.Transaction = transaction;
            try
            {
                command.CommandText = "delete from EngleskaRec where " +
                    $"SrpskaRec={srpska.ID} and RB={e.RB}";
                command.ExecuteNonQuery();
            }
            catch (SqlException ex) { Console.WriteLine(ex.Message); }
        }

        internal void IzmeniZnacenje(SrpskaRec srpska, EngleskaRec e,Korisnik k)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.Transaction = transaction;
            try
            {
                command.CommandText = "update EngleskaRec set Rec=@rec,KoJeUneo=@uneo where " +
                    $"SrpskaRec={srpska.ID} and RB={e.RB}";

                command.Parameters.AddWithValue("@rec", e.Rec);
                command.Parameters.AddWithValue("@uneo", k.ID);
                command.ExecuteNonQuery();

            }
            catch (SqlException ex) { Console.WriteLine(ex.Message); }
         
        }

        internal void DodajNovuRec(SrpskaRec m)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.Transaction = transaction;
            try
            {
                command.CommandText = "insert into SrpskaRec (Rec,KoJeUneo" +
                    ") " +
                    "output inserted.ID values" +
                    " (@rec, @uneo)";

                command.Parameters.AddWithValue("@rec", m.Rec);
                command.Parameters.AddWithValue("@uneo", m.KoJeUneo.ID);



                int emisijaID = (int)command.ExecuteScalar();

                int brojac = 1;

                foreach (EngleskaRec a in m.EngleskaZnacenja)
                {

                    command = new SqlCommand("", connection, transaction);
                    command.CommandText = "insert into EngleskaRec (SrpskaRec,RB" +
                        ",Rec,KoJeUneo) values" +
                    " (@srpska, @rb, @rec,@uneo)";

                    command.Parameters.AddWithValue("@srpska", emisijaID);
                    command.Parameters.AddWithValue("@rb", brojac++);
                    command.Parameters.AddWithValue("@rec", a.Rec);
                    command.Parameters.AddWithValue("@uneo", a.KoJeUneo.ID);

                    command.ExecuteNonQuery();

                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message); return;
            }


        }

        internal List<SrpskaRec> vratiReci()
        {
            List<SrpskaRec> manufacturers = new List<SrpskaRec>();
            SqlCommand command = new SqlCommand("", connection);
            command.CommandText = "SELECT * FROM SrpskaRec join Korisnik k on KoJeUneo=k.ID";
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    SrpskaRec m = new SrpskaRec();
                    m.ID = reader.GetInt32(0);
                    m.Rec = reader.GetString(1);
                    m.KoJeUneo = new Korisnik
                    {
                        ID = reader.GetInt32(2),
                        KorisnickoIme = reader.GetString(6)
                    };
                   
                    manufacturers.Add(m);
                }
            }
            return manufacturers;
        }
    }
}
