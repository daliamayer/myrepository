﻿using Common;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class ClientHandler
    {
        private readonly Socket socket;
        private readonly List<ClientHandler> clients;
        private CommunicationHelper helper;
        FrmServer serverForma;

        public ClientHandler(Socket socket, List<ClientHandler> clients, FrmServer forma)
        {
            this.socket = socket;
            this.clients = clients;
            Helper = new CommunicationHelper(socket);
            serverForma = forma;
        }

        public CommunicationHelper Helper { get => helper; private set => helper = value; }
        public string Username { get; private set; }

        internal void HandleRequests()
        {
            try
            {
                bool kraj = false;
                while (!kraj)
                {
                    Poruka message = Helper.Receive<Poruka>();
                    switch (message.Operation)
                    {
                        case Operation.Login:
                            LoginUser(message);
                            break;
                        case Operation.DodajURecnik:
                            DodajURecnik(message);
                            serverForma.Osvezi();
                            break;
                        case Operation.DaLiPostojiRec:
                            DaLiPostojiRec(message.RecZaRecnik);
                            break;
                        case Operation.Izmeni:
                            Izmeni(message.RecZaRecnik, message.Korisnik);
                            serverForma.Osvezi();
                            break;
                        case Operation.End:
                            OdjavljenKlijent();
                            kraj = true;
                            break;
                        default:
                            break;
                    }

                }
            }
            catch (IOException ex)
            {
                Debug.WriteLine(ex.Message);
            }
            finally
            {
                if (socket != null && socket.Connected)
                {
                    socket.Shutdown(SocketShutdown.Both);
                    socket.Close();
                }
                clients?.Remove(this);

            }

        }

        private void Izmeni(SrpskaRec recZaRecnik, Korisnik korisnik)
        {

            Controller.Instance.Izmeni(recZaRecnik, korisnik);

        }

        private void DaLiPostojiRec(SrpskaRec rec)
        {
            List<SrpskaRec> srpskeReciBaza = Controller.Instance.vratiReci();
            Poruka p = new Poruka();
            SrpskaRec s = srpskeReciBaza.FirstOrDefault(x => x.Rec.ToUpper() == rec.Rec.ToUpper()); ;
            if (s!=null)
            {
                p.IsSuccessful = true;
                p.RecZaRecnik = s;
                
            }
            else p.IsSuccessful = false;
            p.Operation = Operation.DaLiPostojiRec;
            helper.Send(p);
        }

        private void DodajURecnik(Poruka message)
        {
            SrpskaRec s = message.RecZaRecnik;
            List<EngleskaRec> novaZnacenja = new List<EngleskaRec>();

            List<SrpskaRec> srpskeReciBaza = Controller.Instance.vratiReci();


            foreach (SrpskaRec item in srpskeReciBaza)
            {
                if (item.Equals(s))
                {
                    
                    foreach (EngleskaRec e in s.EngleskaZnacenja)
                    {
                        if (item.EngleskaZnacenja.Contains(e))
                        {
                            continue;
                        }
                        else
                        {
                            novaZnacenja.Add(e);
                        }

                    }
                    if (novaZnacenja == null || novaZnacenja.Count == 0)
                    {
                        return;
                    }
                    Controller.Instance.dodajZnacenje(item,novaZnacenja);
                    return;
                }
            }

            Controller.Instance.DodajNovuRec(s);


            

        }

        private void OdjavljenKlijent()
        {
            if (socket != null && socket.Connected)
            {
                socket.Shutdown(SocketShutdown.Both);
                socket.Close();
            }
            clients?.Remove(this);
        }

        private void LoginUser(Poruka message)
        {
            
            List<Korisnik> korisnici = Controller.Instance.vratiKorisnike();


            Korisnik k = korisnici.Find(x => x.KorisnickoIme == message.Korisnik.KorisnickoIme);

            if (k == null)
            {
                Poruka odgovor = new Poruka
                {
                    IsSuccessful = false,
                    ErrorText = "Korisnik ne postoji u bazi!"
                };
                helper.Send(odgovor);
            }
            else {
                Poruka odgovor = new Poruka
                {
                    IsSuccessful = true,
                    Korisnik = k

                };
                helper.Send(odgovor);
                clients.Add(this);
            }
            
               
            
        }

        private void SendToAll(SrpskaRec m, List<EngleskaRec> staraZnacenja = null, List<EngleskaRec> novaZnacenja = null)
        {
            Poruka p = new Poruka();
            p.RecZaRecnik = m;
            p.NovaZnacenja = novaZnacenja;
            p.StaraZnacenja = staraZnacenja;
            p.Operation = Operation.DodataRec;
            
            foreach (ClientHandler client in clients)
            {
                if (client != null) client.Helper.Send(p);
            }
        }

        private void SendToAllExcept(Poruka m)
        {
            //m.Name = Username;
            //m.Operation = Operation.OdjavljenKlijent;
            //foreach (ClientHandler client in clients)
            //{
            //    if (client != this && client.Username != null) client.Helper.Send(m);
            //}
        }

        public void Close()
        {
            if (socket != null && socket.Connected)
            {
                socket.Shutdown(SocketShutdown.Both);
                socket.Close();
            }
            


        }
    }
}
