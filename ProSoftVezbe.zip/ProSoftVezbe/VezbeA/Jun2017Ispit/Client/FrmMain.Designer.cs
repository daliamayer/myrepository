﻿
namespace Client
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gblogin = new System.Windows.Forms.GroupBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUsename = new System.Windows.Forms.TextBox();
            this.lblKorisnik = new System.Windows.Forms.Label();
            this.btnOdjava = new System.Windows.Forms.Button();
            this.btnUnos = new System.Windows.Forms.Button();
            this.btnIzmena = new System.Windows.Forms.Button();
            this.gbUnos = new System.Windows.Forms.GroupBox();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.gblogin.SuspendLayout();
            this.gbUnos.SuspendLayout();
            this.SuspendLayout();
            // 
            // gblogin
            // 
            this.gblogin.Controls.Add(this.btnLogin);
            this.gblogin.Controls.Add(this.label1);
            this.gblogin.Controls.Add(this.txtUsename);
            this.gblogin.Location = new System.Drawing.Point(44, 12);
            this.gblogin.Name = "gblogin";
            this.gblogin.Size = new System.Drawing.Size(461, 88);
            this.gblogin.TabIndex = 0;
            this.gblogin.TabStop = false;
            this.gblogin.Text = "Login";
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(271, 45);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(139, 29);
            this.btnLogin.TabIndex = 2;
            this.btnLogin.Text = "Prijavi se";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Username";
            // 
            // txtUsename
            // 
            this.txtUsename.Location = new System.Drawing.Point(115, 48);
            this.txtUsename.Name = "txtUsename";
            this.txtUsename.Size = new System.Drawing.Size(138, 22);
            this.txtUsename.TabIndex = 0;
            // 
            // lblKorisnik
            // 
            this.lblKorisnik.AutoSize = true;
            this.lblKorisnik.Location = new System.Drawing.Point(195, 115);
            this.lblKorisnik.Name = "lblKorisnik";
            this.lblKorisnik.Size = new System.Drawing.Size(46, 17);
            this.lblKorisnik.TabIndex = 1;
            this.lblKorisnik.Text = "label2";
            // 
            // btnOdjava
            // 
            this.btnOdjava.Location = new System.Drawing.Point(247, 106);
            this.btnOdjava.Name = "btnOdjava";
            this.btnOdjava.Size = new System.Drawing.Size(117, 35);
            this.btnOdjava.TabIndex = 0;
            this.btnOdjava.Text = "Odjavi se";
            this.btnOdjava.UseVisualStyleBackColor = true;
            this.btnOdjava.Click += new System.EventHandler(this.btnOdjava_Click);
            // 
            // btnUnos
            // 
            this.btnUnos.Location = new System.Drawing.Point(284, 38);
            this.btnUnos.Name = "btnUnos";
            this.btnUnos.Size = new System.Drawing.Size(142, 32);
            this.btnUnos.TabIndex = 3;
            this.btnUnos.Text = "Unos reci";
            this.btnUnos.UseVisualStyleBackColor = true;
            this.btnUnos.Click += new System.EventHandler(this.btnUnos_Click);
            // 
            // btnIzmena
            // 
            this.btnIzmena.Location = new System.Drawing.Point(125, 37);
            this.btnIzmena.Name = "btnIzmena";
            this.btnIzmena.Size = new System.Drawing.Size(128, 33);
            this.btnIzmena.TabIndex = 4;
            this.btnIzmena.Text = "Izmena reci";
            this.btnIzmena.UseVisualStyleBackColor = true;
            this.btnIzmena.Click += new System.EventHandler(this.btnIzmena_Click);
            // 
            // gbUnos
            // 
            this.gbUnos.Controls.Add(this.btnUnos);
            this.gbUnos.Controls.Add(this.btnOdjava);
            this.gbUnos.Controls.Add(this.lblKorisnik);
            this.gbUnos.Controls.Add(this.btnIzmena);
            this.gbUnos.Location = new System.Drawing.Point(53, 106);
            this.gbUnos.Name = "gbUnos";
            this.gbUnos.Size = new System.Drawing.Size(452, 151);
            this.gbUnos.TabIndex = 5;
            this.gbUnos.TabStop = false;
            this.gbUnos.Text = "Main";
            // 
            // pnlMain
            // 
            this.pnlMain.Location = new System.Drawing.Point(44, 263);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(461, 494);
            this.pnlMain.TabIndex = 6;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 790);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.gbUnos);
            this.Controls.Add(this.gblogin);
            this.Name = "FrmMain";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmMain_FormClosed);
            this.gblogin.ResumeLayout(false);
            this.gblogin.PerformLayout();
            this.gbUnos.ResumeLayout(false);
            this.gbUnos.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gblogin;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUsename;
        private System.Windows.Forms.Button btnOdjava;
        private System.Windows.Forms.Label lblKorisnik;
        private System.Windows.Forms.Button btnUnos;
        private System.Windows.Forms.Button btnIzmena;
        private System.Windows.Forms.GroupBox gbUnos;
        private System.Windows.Forms.Panel pnlMain;
    }
}

