﻿using Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class ucUnos : UserControl
    {
        private SrpskaRec rec = new SrpskaRec();
        private Korisnik k;
        List<EngleskaRec> engleskaZnacenja=new List<EngleskaRec>();
        public ucUnos(Korisnik k)
        {
            InitializeComponent();
            this.k = k;
            dgvZnacenja.DataSource = new List<EngleskaRec>();
            dgvZnacenja.Columns[0].Visible = false;
            dgvZnacenja.Columns[1].Visible = false;
            dgvZnacenja.Columns[3].Visible = false;
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            string engl = txtEngleskoZnacenje.Text;
            if (string.IsNullOrEmpty(engl) || string.IsNullOrWhiteSpace(engl))
            {
                MessageBox.Show("Morate uneti znacenje!");
                return;
            }

            EngleskaRec en = new EngleskaRec
            {
                Rec = engl,
                KoJeUneo = k
            };

            if (engleskaZnacenja != null && engleskaZnacenja.Contains(en))
            {
                MessageBox.Show("Vec ste uneli dato znacenje!");
                return;
            }

            txtEngleskoZnacenje.Text = "";
            engleskaZnacenja.Add(en);
            dgvZnacenja.DataSource = null;
            dgvZnacenja.DataSource = engleskaZnacenja;
            dgvZnacenja.Columns[0].Visible = false;
            dgvZnacenja.Columns[1].Visible = false;
            dgvZnacenja.Columns[3].Visible = false;

        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            if (dgvZnacenja.SelectedRows == null || dgvZnacenja.SelectedRows.Count == 0)
            {
                MessageBox.Show("Morate selektovati red da biste ga obrisali!");
                return;
            }

            EngleskaRec en = (EngleskaRec)dgvZnacenja.SelectedRows[0].DataBoundItem;
            engleskaZnacenja.Remove(en);
            dgvZnacenja.DataSource = null;
            dgvZnacenja.DataSource = engleskaZnacenja;
            dgvZnacenja.Columns[0].Visible = false;
            dgvZnacenja.Columns[1].Visible = false;
            dgvZnacenja.Columns[3].Visible = false;
        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {
            string srp = txtSrpskaRec.Text;
            if (string.IsNullOrEmpty(srp) || string.IsNullOrWhiteSpace(srp))
            {
                MessageBox.Show("Morate uneti rec na srpskom!");
                return;
            }
            if (engleskaZnacenja == null || engleskaZnacenja.Count == 0)
            {
                MessageBox.Show("Morate uneti bar jedno englesko znacenje!");
                return;
            }

            SrpskaRec s = new SrpskaRec
            {
                Rec = srp,
                KoJeUneo = k,
                EngleskaZnacenja = engleskaZnacenja
            };

            Poruka p = new Poruka();
            p.RecZaRecnik = s;
            p.Operation = Operation.DodajURecnik;
            p.Korisnik = k;
            Communication.Instance.Send(p);
            MessageBox.Show("Uspesno sacuvano");
            txtSrpskaRec.Text = "";
            txtEngleskoZnacenje.Text = "";
            engleskaZnacenja.Clear();
            dgvZnacenja.DataSource = null;
            dgvZnacenja.DataSource = engleskaZnacenja;
            dgvZnacenja.Columns[0].Visible = false;
            dgvZnacenja.Columns[1].Visible = false;
            dgvZnacenja.Columns[3].Visible = false;

        }
    }
}
