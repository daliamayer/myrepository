﻿
namespace Client
{
    partial class ucUnos
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSrpskaRec = new System.Windows.Forms.TextBox();
            this.txtEngleskoZnacenje = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvZnacenja = new System.Windows.Forms.DataGridView();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.btnObrisi = new System.Windows.Forms.Button();
            this.btnSacuvaj = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvZnacenja)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSrpskaRec
            // 
            this.txtSrpskaRec.Location = new System.Drawing.Point(183, 67);
            this.txtSrpskaRec.Name = "txtSrpskaRec";
            this.txtSrpskaRec.Size = new System.Drawing.Size(204, 22);
            this.txtSrpskaRec.TabIndex = 0;
            // 
            // txtEngleskoZnacenje
            // 
            this.txtEngleskoZnacenje.Location = new System.Drawing.Point(183, 116);
            this.txtEngleskoZnacenje.Name = "txtEngleskoZnacenje";
            this.txtEngleskoZnacenje.Size = new System.Drawing.Size(204, 22);
            this.txtEngleskoZnacenje.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Srpska rec";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Englesko znacenje";
            // 
            // dgvZnacenja
            // 
            this.dgvZnacenja.AllowUserToAddRows = false;
            this.dgvZnacenja.AllowUserToDeleteRows = false;
            this.dgvZnacenja.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvZnacenja.Location = new System.Drawing.Point(183, 230);
            this.dgvZnacenja.Name = "dgvZnacenja";
            this.dgvZnacenja.ReadOnly = true;
            this.dgvZnacenja.RowHeadersWidth = 51;
            this.dgvZnacenja.RowTemplate.Height = 24;
            this.dgvZnacenja.Size = new System.Drawing.Size(204, 174);
            this.dgvZnacenja.TabIndex = 6;
            // 
            // btnDodaj
            // 
            this.btnDodaj.Location = new System.Drawing.Point(183, 158);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(97, 43);
            this.btnDodaj.TabIndex = 7;
            this.btnDodaj.Text = "Dodaj znacenje";
            this.btnDodaj.UseVisualStyleBackColor = true;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // btnObrisi
            // 
            this.btnObrisi.Location = new System.Drawing.Point(286, 158);
            this.btnObrisi.Name = "btnObrisi";
            this.btnObrisi.Size = new System.Drawing.Size(101, 43);
            this.btnObrisi.TabIndex = 8;
            this.btnObrisi.Text = "Obrisi znacenje";
            this.btnObrisi.UseVisualStyleBackColor = true;
            this.btnObrisi.Click += new System.EventHandler(this.btnObrisi_Click);
            // 
            // btnSacuvaj
            // 
            this.btnSacuvaj.Location = new System.Drawing.Point(204, 421);
            this.btnSacuvaj.Name = "btnSacuvaj";
            this.btnSacuvaj.Size = new System.Drawing.Size(155, 35);
            this.btnSacuvaj.TabIndex = 9;
            this.btnSacuvaj.Text = "Sacuvaj rec";
            this.btnSacuvaj.UseVisualStyleBackColor = true;
            this.btnSacuvaj.Click += new System.EventHandler(this.btnSacuvaj_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(214, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "DODAVANJE RECI";
            // 
            // ucUnos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnSacuvaj);
            this.Controls.Add(this.btnObrisi);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.dgvZnacenja);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtEngleskoZnacenje);
            this.Controls.Add(this.txtSrpskaRec);
            this.Name = "ucUnos";
            this.Size = new System.Drawing.Size(438, 486);
            ((System.ComponentModel.ISupportInitialize)(this.dgvZnacenja)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSrpskaRec;
        private System.Windows.Forms.TextBox txtEngleskoZnacenje;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvZnacenja;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.Button btnObrisi;
        private System.Windows.Forms.Button btnSacuvaj;
        private System.Windows.Forms.Label label3;
    }
}
