﻿
namespace Client
{
    partial class ucIzmena
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtRecZaIzmenu = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvZnacenjaIzmena = new System.Windows.Forms.DataGridView();
            this.btnIzmeni = new System.Windows.Forms.Button();
            this.btnPromeniZnacenja = new System.Windows.Forms.Button();
            this.gbPromena = new System.Windows.Forms.GroupBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)(this.dgvZnacenjaIzmena)).BeginInit();
            this.gbPromena.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtRecZaIzmenu
            // 
            this.txtRecZaIzmenu.Location = new System.Drawing.Point(154, 80);
            this.txtRecZaIzmenu.Name = "txtRecZaIzmenu";
            this.txtRecZaIzmenu.Size = new System.Drawing.Size(196, 22);
            this.txtRecZaIzmenu.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(62, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Srpska rec";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(190, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "IZMENA RECI";
            // 
            // dgvZnacenjaIzmena
            // 
            this.dgvZnacenjaIzmena.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvZnacenjaIzmena.Location = new System.Drawing.Point(39, 21);
            this.dgvZnacenjaIzmena.Name = "dgvZnacenjaIzmena";
            this.dgvZnacenjaIzmena.RowHeadersWidth = 51;
            this.dgvZnacenjaIzmena.RowTemplate.Height = 24;
            this.dgvZnacenjaIzmena.Size = new System.Drawing.Size(311, 282);
            this.dgvZnacenjaIzmena.TabIndex = 3;
            // 
            // btnIzmeni
            // 
            this.btnIzmeni.Location = new System.Drawing.Point(119, 332);
            this.btnIzmeni.Name = "btnIzmeni";
            this.btnIzmeni.Size = new System.Drawing.Size(137, 34);
            this.btnIzmeni.TabIndex = 4;
            this.btnIzmeni.Text = "Izmeni znacenja";
            this.btnIzmeni.UseVisualStyleBackColor = true;
            this.btnIzmeni.Click += new System.EventHandler(this.btnIzmeni_Click);
            // 
            // btnPromeniZnacenja
            // 
            this.btnPromeniZnacenja.Location = new System.Drawing.Point(184, 117);
            this.btnPromeniZnacenja.Name = "btnPromeniZnacenja";
            this.btnPromeniZnacenja.Size = new System.Drawing.Size(138, 29);
            this.btnPromeniZnacenja.TabIndex = 5;
            this.btnPromeniZnacenja.Text = "Promeni znacenja ";
            this.btnPromeniZnacenja.UseVisualStyleBackColor = true;
            this.btnPromeniZnacenja.Click += new System.EventHandler(this.btnPromeniZnacenja_Click);
            // 
            // gbPromena
            // 
            this.gbPromena.Controls.Add(this.dgvZnacenjaIzmena);
            this.gbPromena.Controls.Add(this.btnIzmeni);
            this.gbPromena.Location = new System.Drawing.Point(65, 152);
            this.gbPromena.Name = "gbPromena";
            this.gbPromena.Size = new System.Drawing.Size(394, 372);
            this.gbPromena.TabIndex = 6;
            this.gbPromena.TabStop = false;
            // 
            // ucIzmena
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gbPromena);
            this.Controls.Add(this.btnPromeniZnacenja);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtRecZaIzmenu);
            this.Name = "ucIzmena";
            this.Size = new System.Drawing.Size(497, 540);
            ((System.ComponentModel.ISupportInitialize)(this.dgvZnacenjaIzmena)).EndInit();
            this.gbPromena.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtRecZaIzmenu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.DataGridView dgvZnacenjaIzmena;
      
        private System.Windows.Forms.Button btnIzmeni;
        private System.Windows.Forms.Button btnPromeniZnacenja;
        public System.Windows.Forms.GroupBox gbPromena;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}
