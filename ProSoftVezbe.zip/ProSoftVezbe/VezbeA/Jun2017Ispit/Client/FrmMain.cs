﻿using Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class FrmMain : Form
    {
        public Korisnik trenutnoPrijavljeni;
        Thread nit;
        List<EngleskaRec> engleskaZnacenja = new List<EngleskaRec>();
        ucIzmena izmena;
       
     
        public FrmMain()
        {
            InitializeComponent();
            gbUnos.Visible = false;
      

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                Communication.Instance.Connect();

                Poruka p = new Poruka();
                p.Korisnik = new Korisnik { KorisnickoIme=txtUsename.Text };
                p.Operation = Operation.Login;
                Communication.Instance.Send(p);
                Poruka odg = Communication.Instance.ReadMessage();
                if (!odg.IsSuccessful)
                {
                    MessageBox.Show(odg.ErrorText);
                    txtUsename.Text = "";
                    return;

                }
                trenutnoPrijavljeni = odg.Korisnik;
                lblKorisnik.Text = trenutnoPrijavljeni.KorisnickoIme;
                gblogin.Visible = false;
                gbUnos.Visible = true;
                InitListener();
            }
            catch (SocketException ex)
            {
                MessageBox.Show("Server nije pokrenut!");
                return;

            }
            catch (IOException ex)
            {
                MessageBox.Show("Server je pao!");

            }


        }

        private void InitListener()
        {
            nit = new Thread(CitajPoruke);
            nit.IsBackground = true;
            nit.Start();
        }

        private void CitajPoruke()
        {
            try
            {
                while (true)
                {
                    Poruka m = Communication.Instance.ReadMessage();

                    switch (m.Operation)
                    {
                        case Operation.End:
                            Invoke(new Action(() => {
                                MessageBox.Show("Server je pao!");
                                gbUnos.Visible = false;
                                gblogin.Visible = true;
                                pnlMain.Controls.Clear();
                                Communication.Instance.Disconnect();
                            }));
                            break;
                        case Operation.DaLiPostojiRec:
                            if (!m.IsSuccessful)
                            {
                                Invoke(new Action(() =>
                                {
                                    MessageBox.Show("Rec ne postoji u bazi, dodajte rec!");
                                    pnlMain.Controls.Clear();
                                    pnlMain.Controls.Add(new ucUnos(trenutnoPrijavljeni)
                                    {
                                        Dock = DockStyle.Fill
                                    });
                                }));
                            }
                            else {
                                Invoke(new Action(() =>
                                {
                                    izmena.gbPromena.Visible = true;
                                    izmena.s = m.RecZaRecnik;
                                    izmena.bs.DataSource= m.RecZaRecnik.EngleskaZnacenja;
                                    izmena.dgvZnacenjaIzmena.DataSource = izmena.bs;
                                }));

                            }
                            
                            break;


                        default:
                            break;
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                
            }
        }

        private string Ispis2(SrpskaRec rec, List<EngleskaRec> novaZnacenja, List<EngleskaRec> staraZnacenja)
        {
            string pom = "Nova rec: " + rec.Rec + ", novo znacenje: ";

            foreach (EngleskaRec e in novaZnacenja)
            {
                pom += e.Rec + ", ";
            }

            pom += "korisnik: " + rec.KoJeUneo;
            pom += ", ostala znacenja: ";

            foreach (EngleskaRec e in staraZnacenja)
            {
                pom += e.Rec + ", ";
            }

            int duzina = pom.Length;

            return pom;
        }

        private string Ispis1(SrpskaRec rec)
        {
            string pom = "Nova rec: " + rec.Rec+", znacenje: ";

            foreach (EngleskaRec e in rec.EngleskaZnacenja)
            {
                pom += e.Rec + ", ";
            }

            pom += "korisnik: "+ rec.KoJeUneo;

            return pom;
            
        }

        private void Odjava()
        {
            Communication.Instance.Odjava(trenutnoPrijavljeni);
        
        }

        private void btnOdjava_Click(object sender, EventArgs e)
        {

            Odjava();
            gblogin.Visible = true;
            gbUnos.Visible = false;
            pnlMain.Controls.Clear();
        }

        private void FrmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            Odjava();
            Environment.Exit(0);
        }

        private void btnIzmena_Click(object sender, EventArgs e)
        {
            pnlMain.Controls.Clear();
            izmena = new ucIzmena(trenutnoPrijavljeni)
            {
                Dock = DockStyle.Fill
            };
                pnlMain.Controls.Add(izmena); 

            
        }

        private void btnUnos_Click(object sender, EventArgs e)
        {
            pnlMain.Controls.Clear();
            pnlMain.Controls.Add(new ucUnos(trenutnoPrijavljeni)
            {
                Dock = DockStyle.Fill
            }) ;
        }
    }
}
