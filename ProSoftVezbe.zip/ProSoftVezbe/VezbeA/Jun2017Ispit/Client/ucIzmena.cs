﻿using Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class ucIzmena : UserControl
    {
        public SrpskaRec s = new SrpskaRec();
        public BindingSource bs = new BindingSource();
        private Korisnik trenutni;
        public ucIzmena(Korisnik prijavljeni)
        {
            InitializeComponent();
            trenutni = prijavljeni;
            gbPromena.Visible = false;
            dgvZnacenjaIzmena.DataSource = new List<EngleskaRec>();
            dgvZnacenjaIzmena.Columns[0].Visible = false;
            //dgvZnacenjaIzmena.Columns[1].Visible = false;
            dgvZnacenjaIzmena.Columns[3].Visible = false;

        }



        private void btnPromeniZnacenja_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtRecZaIzmenu.Text) || string.IsNullOrWhiteSpace(txtRecZaIzmenu.Text))
            {
                MessageBox.Show("Morate uneti rec!");
                return;
            }

            SrpskaRec s = new SrpskaRec() { Rec = txtRecZaIzmenu.Text };
            Poruka p = new Poruka();
            p.RecZaRecnik = s;
            p.Operation = Operation.DaLiPostojiRec;
            Communication.Instance.Send(p);
        }

        private void btnIzmeni_Click(object sender, EventArgs e)
        {
            s.EngleskaZnacenja = (List<EngleskaRec>)bs.DataSource;
            Poruka p = new Poruka();
            p.Operation = Operation.Izmeni;
            p.Korisnik = trenutni;
            p.RecZaRecnik = s;
            Communication.Instance.Send(p);
            MessageBox.Show("Uspesno sacuvano!");
            txtRecZaIzmenu.Text = "";
            gbPromena.Visible = false;
        }
    }
}
