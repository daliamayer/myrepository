﻿using DatabaseBroker;
using Domain;
using Microsoft.Win32;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ApplicationLogic
{
    public class Controller

    {
        private static Controller instance;
        private DatabaseBroker.Broker broker = new DatabaseBroker.Broker();

        private List<User> korisnici = new List<User>() { 
        new User(){ 
        Username="pera",
        Password="pera",
        FirstName="pera",
        LastName="peric",
        UserId=1
        
        } };
        private Controller()
        {
        }

        public static Controller Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Controller();
                }
                return instance;
            }
        }


        public User Login(User user)
        {
            return korisnici.FirstOrDefault(x=>x.Username==user.Username && x.Password==user.Password);
           
        }


    }
}
