﻿using ApplicationLogic;
using Common;
using Domain;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class ClientHandler
    {
        private Socket socket;
        private CommunicationHelper helper;
        private List<ClientHandler> clients = new List<ClientHandler>();

        public EventHandler OdjavljenKlijent;

        public ClientHandler(Socket socket, List<ClientHandler> aktivni)
        {
            this.socket = socket;
            helper = new CommunicationHelper(socket);
            clients = aktivni;
        }

        private bool kraj = false;
        public void HandleRequests()
        {
            try
            {
                while (!kraj)
                {
                    Request request = helper.Receive<Request>();
                    CreateResponse(request);
                   
                }
            }
            catch (IOException ex)
            {
                Debug.WriteLine(">>>" + ex.Message);
            }
            finally
            {
                CloseSocket();
            }
        }


        public void CreateResponse(Request request)
        {
            Response response = new Response();
            try
            {
                switch (request.Operation)
                {
                    case Operation.Login:
                        response.Result = Controller.Instance.Login((User)request.RequestObject);
                        if (response.Result != null)
                        {
                            clients.Add(this);
                            Console.WriteLine(clients.Count);
                        }
                        helper.Send(response);
                        break;
                   
                    case Operation.End:
                        
                        CloseSocket();
                        Console.WriteLine(clients.Count);
                        kraj = true;
                      
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                response.IsSuccessful = false;
                response.Message = ex.Message;
            }
            
        }
        private object lockobject = new object();
        internal void CloseSocket()
        {
            lock (lockobject)
            {
                if (socket != null)
                {
                    kraj = true;
                    socket.Shutdown(SocketShutdown.Both);
                    socket.Close();
                    socket = null;
                    clients.Remove(this);
                }
            }
        }
    }
}
