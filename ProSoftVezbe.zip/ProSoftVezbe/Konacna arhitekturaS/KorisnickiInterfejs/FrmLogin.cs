﻿using Domain;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorisnickiInterfejs
{
    public partial class FrmLogin : Form
    {
       
        public FrmLogin()
        {
            InitializeComponent();
            
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
          

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                txtUsername.BackColor = Color.Salmon;
                txtPassword.BackColor = Color.Salmon;
                return;
            }

            try
            {
                User user = new User()
                {
                    Username = username,
                    Password = password,
                };

                Communication.Instance.Connect();
                user = Communication.Instance.Login(user);

                if (user != null)
                {
                    MessageBox.Show($"Welcome, {user.FirstName} {user.LastName}!");
                    this.Visible = false;
                    FrmMain main = new FrmMain(user);
                    main.ShowDialog();
                }
                else
                {
                    MessageBox.Show("User doesnt exist!");
                }
            }
            
            catch (SocketException ex)
            {
                MessageBox.Show("Server je pao!");
            }
            catch (IOException ex)
            {
                MessageBox.Show("Server je pao!");
            }

        }

        private void FrmLogin_FormClosed(object sender, FormClosedEventArgs e)
        {

            Communication.Instance.Close();
            //Environment.Exit(0);
        }
    }
}
