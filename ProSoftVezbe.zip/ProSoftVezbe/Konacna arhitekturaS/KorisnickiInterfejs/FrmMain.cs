﻿using Domain;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorisnickiInterfejs
{
    public partial class FrmMain : Form
    {
        public User User { get; }

        public FrmMain()
        {
          
        }

        public FrmMain(User user)
        {
            InitializeComponent();
            User = user;
        }

        private void FrmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
                Communication.Instance.Close();
                //Environment.Exit(0);  
        }
    }
}
