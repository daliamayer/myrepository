﻿using Common;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace KorisnickiInterfejs
{
    public class Communication
    {
        private Socket socket;
        private CommunicationHelper helper;
        private static Communication instance;

        private Communication()
        {
        }
        public static Communication Instance
        {
            get
            {
                if (instance == null) instance = new Communication();
                return instance;
            }
        }

      

        public void Connect()
        {
            if (socket == null || !socket.Connected)
            {
                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                socket.Connect("127.0.0.1", 9999);
                helper = new CommunicationHelper(socket);
            }
        }
        public User Login(User user)
        {
            Request r = new Request();
            r.Operation = Operation.Login;
            r.RequestObject = user;
            helper.Send(r);
            return (User)helper.Receive<Response>().Result;
        }

        public void Close()
        {
            if (socket == null) return;
            Request r = new Request();
            r.Operation = Operation.End;
          
            helper.Send(r);
            
            socket.Shutdown(SocketShutdown.Both);
            socket.Close();
            socket = null;
        }

        
    }
}
